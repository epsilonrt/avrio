var a00071 =
[
    [ "dPress", "a00071.html#a635330fbb5f50ac7f817fbd8bdf0a4c6", null ],
    [ "dTemp", "a00071.html#af3d8e80e78b332ff5fcf9592c3163215", null ]
];