var a00051 =
[
    [ "sByte", "a00051.html#aec52780704165a5ed573f7d750ca1246", null ],
    [ "sNid", "a00051.html#ad1c6102b2db482111beb491832b2f0ab", null ],
    [ "u32Mid", "a00051.html#acb9bc9b68fc307eafbb50d766b162fe4", null ],
    [ "u8ChecksumSeed", "a00051.html#ac8896bd048de60e055d4716c7f7eb691", null ],
    [ "u8CrcSeed", "a00051.html#add943938b3cffa7770aa1ad413482426", null ],
    [ "u8Mid1", "a00051.html#a22a4c91d45c89570de5bb3fb17346099", null ],
    [ "u8Mid2", "a00051.html#abb88c3341c41dd6077a62545ed4ad5a6", null ],
    [ "u8Mid3", "a00051.html#ad91a7dff7c59b5f4d20134bdc7762481", null ],
    [ "u8Mid4", "a00051.html#af5f1aa932f211036158d607367cc61c8", null ]
];