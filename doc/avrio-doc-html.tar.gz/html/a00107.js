var a00107 =
[
    [ "hdr", "a00107.html#a3991964bd0abeef796f26ff259f15350", null ],
    [ "status", "a00107.html#a8223df323335ff0e7571ab47652700b2", null ],
    [ "type", "a00107.html#a04362132a8876cebad75edfef2474457", null ]
];