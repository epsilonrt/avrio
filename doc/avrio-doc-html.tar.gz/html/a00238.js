var a00238 =
[
    [ "xAdcSensor", "a00054.html", [
      [ "eType", "a00054.html#a0407051cc2380c137bd76197fb3d2801", null ],
      [ "pSetting", "a00054.html#a586c0be18a2bdb017ae3dd4e4a5c2c7d", null ],
      [ "ucAdcChan", "a00054.html#a3436e5fa442b8ff063d7b6e8b53b421d", null ],
      [ "ucAdcScale", "a00054.html#afecaf8005afc7ee1baf0824609fd188e", null ],
      [ "ucMeanTerms", "a00054.html#a37bfa805f93f881b218162465ecba9b0", null ]
    ] ],
    [ "xAdcSensorLinearSetting", "a00055.html", [
      [ "dRawMax", "a00055.html#a13ed04b9c4f33a2df21606e5461d4f4f", null ],
      [ "dRawMin", "a00055.html#ac34937d170995e7a4a924c5a717498f3", null ],
      [ "dValueMax", "a00055.html#a1b060ad37bb25cab59ca93da21b146ec", null ],
      [ "dValueMin", "a00055.html#a669295b7e3757633ca4c3eb42787f7d6", null ]
    ] ],
    [ "xAdcSensorNlinearSetting", "a00056.html", [
      [ "dCoeff", "a00056.html#a2589c3397d4e20cd0b8675b573ee32ac", null ],
      [ "dRawToValue", "a00056.html#a4376bcc1231980c947aa1c25f5c79d34", null ]
    ] ],
    [ "xAdcSensorSetting", "a00057.html", [
      [ "xLin", "a00057.html#add4c077435d6c270f2a69e1864aea689", null ],
      [ "xNlin", "a00057.html#af0ab8dde341ab73ee206bbba9a0b8c0a", null ]
    ] ],
    [ "ADC_SENSOR_SETTING_LINEAR", "a00238.html#gace02c1d2d241f4433bb1cd2d5bb7d57f", null ],
    [ "ADC_SENSOR_SETTING_NLINEAR", "a00238.html#ga23a1d1547f4fbe5cf6d747e9edbee14e", null ],
    [ "dAdcSensorConvert", "a00238.html#gaa42b7cfe1993f33d546b2bc5e27cd5d0", null ],
    [ "xAdcSensor", "a00238.html#ga4a9f83f90b9467b59a499c1de7b62628", null ],
    [ "xAdcSensorLinearSetting", "a00238.html#gae4dd5f3e2e74f9059ec2f4b74e607d18", null ],
    [ "xAdcSensorNlinearSetting", "a00238.html#ga9dbe342ac06eebaf2216d7c374696859", null ],
    [ "xAdcSensorSetting", "a00238.html#ga3af51afcef0c3bc0810acd9637b6255f", null ],
    [ "eAdcSensorType", "a00238.html#ga6b0be723882d05ec6f0e3bbabdbae1ce", [
      [ "ADC_SENSOR_LINEAR", "a00238.html#gga6b0be723882d05ec6f0e3bbabdbae1cea333977689287fd373927848807c6983b", null ],
      [ "ADC_SENSOR_NLINEAR", "a00238.html#gga6b0be723882d05ec6f0e3bbabdbae1ceaa40d86969ce5da32917644225b9daad5", null ]
    ] ],
    [ "dAdcSensorGetValue", "a00238.html#ga250f435a19407651be537f5e75dc207b", null ],
    [ "dAdcSensorRawToValue", "a00238.html#ga9e1d43a4944e4a3cae223c7ec2318222", null ],
    [ "usAdcSensorGetRaw", "a00238.html#gafcd8ec9898e26063731cb057e1e2bb0c", null ],
    [ "vAdcSensorInit", "a00238.html#ga398668e2bd48e2d94744ce53f5d067fd", null ]
];