var a00120 =
[
    [ "ach_mask", "a00120.html#a037282a1c5bd27aa99ccd0c2dc6e7afd", null ],
    [ "data", "a00120.html#a76536e777faddd7de80efa692207906d", null ],
    [ "dch_mask", "a00120.html#a2a56ae8a00a1bbdf27320ff3b2812360", null ],
    [ "hdr", "a00120.html#ab94d4427ba2c116bee9ce2b0d434bce0", null ],
    [ "num_samples", "a00120.html#a00c863557e23b4f9f22f8db48581e317", null ],
    [ "opt", "a00120.html#a7753f7fb1729acc85739994af837c9ce", null ],
    [ "src16", "a00120.html#a3e846641a029a13ec29e9a63a2d05598", null ],
    [ "src64", "a00120.html#a8f8a28031d4ce20df0cffb63885e9fa1", null ],
    [ "type", "a00120.html#a03b2a341b99660c17e07c1836e039cb8", null ]
];