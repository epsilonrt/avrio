var a00320 =
[
    [ "XMEM_BUS_KEEPER", "a00320.html#gae1fc8b1e0142248abba0c779ab38eb71", null ],
    [ "XMEM_BUS_PULLUP_RESISTOR", "a00320.html#ga792640e446342fa76de4876cd3f88a31", null ],
    [ "XMEM_BUS_WIDTH_A10", "a00320.html#gacd5f36cdfbc361a4d8f6b524c8964af0", null ],
    [ "XMEM_BUS_WIDTH_A11", "a00320.html#ga47556fd4d879dfee047317d029d5f0d0", null ],
    [ "XMEM_BUS_WIDTH_A12", "a00320.html#gadb66bf3015e50372723c91c7644e59b9", null ],
    [ "XMEM_BUS_WIDTH_A13", "a00320.html#ga6e8d3cf4f40f9051f2740a771556dde7", null ],
    [ "XMEM_BUS_WIDTH_A14", "a00320.html#ga9334981564268feb5c4da3268bab21e7", null ],
    [ "XMEM_BUS_WIDTH_A15", "a00320.html#ga536aefc7868e22ec9e4fde6db1070724", null ],
    [ "XMEM_BUS_WIDTH_A7", "a00320.html#gaece433c0f245fc6e16b7db4808de608d", null ],
    [ "XMEM_BUS_WIDTH_A9", "a00320.html#gab7cb7935647311f6196d8a8ab5f81a69", null ],
    [ "eXmemSectorLimit", "a00320.html#ga0b7998bc760b61a4c6588d53825fcdf5", [
      [ "XMEM_SECTOR_LIMIT_1100", "a00320.html#gga0b7998bc760b61a4c6588d53825fcdf5a71b259f41148d7ce7a363280b8df654b", null ],
      [ "XMEM_SECTOR_LIMIT_2000", "a00320.html#gga0b7998bc760b61a4c6588d53825fcdf5a068088b366cec0c81ddd7085bf85bce7", null ],
      [ "XMEM_SECTOR_LIMIT_4000", "a00320.html#gga0b7998bc760b61a4c6588d53825fcdf5a7ec8d1a567f7f987d214e1c0c9f310e0", null ],
      [ "XMEM_SECTOR_LIMIT_6000", "a00320.html#gga0b7998bc760b61a4c6588d53825fcdf5acf282aa1e5d33fefd5641d76967f3028", null ],
      [ "XMEM_SECTOR_LIMIT_8000", "a00320.html#gga0b7998bc760b61a4c6588d53825fcdf5a3b1c521b949334fdc3dd36c966bc5d51", null ],
      [ "XMEM_SECTOR_LIMIT_A000", "a00320.html#gga0b7998bc760b61a4c6588d53825fcdf5a4987b8501718007e9a003897f8d9847f", null ],
      [ "XMEM_SECTOR_LIMIT_C000", "a00320.html#gga0b7998bc760b61a4c6588d53825fcdf5a02f4c0f8d4bd2907b65b79612e9c4675", null ],
      [ "XMEM_SECTOR_LIMIT_E000", "a00320.html#gga0b7998bc760b61a4c6588d53825fcdf5aad83d420bef12d65f967726723efa1e1", null ]
    ] ],
    [ "__attribute__", "a00320.html#ga6067df9f18c3c47a34c4ad941f02d966", null ]
];