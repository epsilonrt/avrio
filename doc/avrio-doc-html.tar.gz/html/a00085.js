var a00085 =
[
    [ "ucDate", "a00085.html#a1700ae9f719055bde630bddffa78a292", null ],
    [ "ucHour", "a00085.html#aaf97e00656b44e3cb805236b1c20100a", null ],
    [ "ucMinute", "a00085.html#a6280e079cdf092c1535639952253a791", null ],
    [ "ucMonth", "a00085.html#a7e74c14b2bb1f5f1e9c2aa199f5afc1d", null ],
    [ "ucSecond", "a00085.html#af6b4028eac425379fddfa2643e4d1e73", null ],
    [ "ucWeekDay", "a00085.html#a12b6bdfdfa4887a0319238282eb57f86", null ],
    [ "usYear", "a00085.html#a6bb6154e7c660db9c24b93eaae698812", null ]
];