var a00252 =
[
    [ "CONFIG_AX25_FRAME_BUF_LEN", "a00252.html#ga7814a5985786c36227869bfc41932ac5", null ],
    [ "CONFIG_AX25_RPT_LST", "a00252.html#ga50a6a1f5849a9aaffc10a3689951436d", null ]
];