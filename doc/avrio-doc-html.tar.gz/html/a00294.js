var a00294 =
[
    [ "xSem", "a00294.html#ga620629ded1ab63c038d6cb609dc117f1", null ],
    [ "xSemValue", "a00294.html#gabead6c88b86526825fba04b28ac0e127", null ],
    [ "vSemInit", "a00294.html#gab3c5efa953a139443a39659da0f74950", null ],
    [ "vSemPost", "a00294.html#gad72a55697f901cce034d9980e0dc70cd", null ],
    [ "vSemWait", "a00294.html#ga6da1cfa83ff4138f812e3698b5221e16", null ],
    [ "xSemTryWait", "a00294.html#gaa20d0dfc18aa0de03144fceccccea24a", null ]
];