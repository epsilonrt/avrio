var a00285 =
[
    [ "Menus hiérarchiques textuels", "a00286.html", "a00286" ],
    [ "xTerm", "a00088.html", [
      [ "eFlag", "a00088.html#a30cc76020e33ff13dd3bce17a73db12b", null ],
      [ "pxInputStream", "a00088.html#a2a09d7dff4acc0fa024986748bf9c5ff", null ],
      [ "pxMenu", "a00088.html#aad24c525c3d003ce9b1a474c5c6adc0b", null ],
      [ "pxOuputStream", "a00088.html#ac2c7edc7ce69bd75a281a2ea3d710789", null ],
      [ "xPos", "a00088.html#a8c950ccdabe66b419e55fde34089d1c6", null ],
      [ "xSize", "a00088.html#ab8342064a4055a005e1c837facf31d72", null ]
    ] ],
    [ "xTermPos", "a00089.html", [
      [ "iColumn", "a00089.html#ab3d81572ef56e9ece500b454ac93fda0", null ],
      [ "iLine", "a00089.html#a2c622d008a063f80c4932d986d945be0", null ]
    ] ],
    [ "xTermSize", "a00090.html", [
      [ "iHSize", "a00090.html#a6b7f649b2174397848f43eacf6a0f480", null ],
      [ "iVSize", "a00090.html#a81c6d9fdac3e7a47c1a894a6a32ec403", null ]
    ] ],
    [ "xTerm", "a00285.html#ga1dfeb7e2d984fc05cda79b8f451ef081", null ],
    [ "xTermPos", "a00285.html#gac9fac6b0a4fb6ef47685d670a6f048c6", null ],
    [ "xTermSize", "a00285.html#gafd5e44cb9d072c1b180ab4cf8b0055aa", null ],
    [ "eTermFlag", "a00285.html#gaee4f671f6dd243b79cfb0bac16832fb1", null ],
    [ "iTermGetDec", "a00285.html#gab3f6feb7b4b20de192eaddd6b0a80646", null ],
    [ "iTermGetHex", "a00285.html#gabcf6fe2df2e4018246b5f9c95bef0ecd", null ],
    [ "iTermGetStr", "a00285.html#ga28b962dee22d152a908fe2429b12f2ad", null ],
    [ "pxTermGetMenu", "a00285.html#gad49f8e9549d863c1c597ca04ae1b3e9d", null ],
    [ "vTermPutDec", "a00285.html#gad97b3b9431e8c1dd078666dbfbee5159", null ],
    [ "vTermPutHexByte", "a00285.html#ga1b05c0a0dfe407ffd62524b80cb50c25", null ],
    [ "vTermPutHexBytes", "a00285.html#gae98f12f6b7cbc27b0940ea310a65db70", null ],
    [ "vTermPutHexDword", "a00285.html#ga649a3f6fcf6780fa9a805cefb9c2b952", null ],
    [ "vTermPutHexWord", "a00285.html#gaaef55ac9627410b9649e2193e44fcd6b", null ],
    [ "vTermSetMenu", "a00285.html#ga2c34f018b8fa61ee5afbc81b4473d630", null ]
];