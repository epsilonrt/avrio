var a00274 =
[
    [ "xKalmanFilter", "a00073.html", [
      [ "fAngle", "a00073.html#a3b5aa09fea2bb4b525a71bff19b28fcf", null ],
      [ "fBias", "a00073.html#a8562e69be9221dacb1322e58f294824d", null ],
      [ "fK", "a00073.html#a87dce26c1f36252110c31c264738aebf", null ],
      [ "fP", "a00073.html#ada23db284e7f7c1e3322fc6901d57b7c", null ],
      [ "fQAngle", "a00073.html#a4360443b3b02d78070016c50e526d5c1", null ],
      [ "fQBias", "a00073.html#ac975927d80cb8be963376c83175c394e", null ],
      [ "fRate", "a00073.html#ad5eca15a9fd89d8de8049a9cd54df43c", null ],
      [ "fRMeasure", "a00073.html#a2c97a6653c647ab279f1b3ae9bcd4e1f", null ],
      [ "fS", "a00073.html#a7716d325c935737dd368603517c6947b", null ],
      [ "fY", "a00073.html#a2d2a3e4db35164c6b7352681109a8abe", null ]
    ] ],
    [ "vKalmanInit", "a00274.html#ga27911094628973394ba90c84b128bbbd", null ],
    [ "vKalmanProcess", "a00274.html#ga4bfe01b79669bfebb346f9e46bad0d42", null ]
];