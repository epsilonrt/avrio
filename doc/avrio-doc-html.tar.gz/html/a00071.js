var a00071 =
[
    [ "bFirstUpdate", "a00071.html#a9dad3f115202f651c6c787d39d1f5b5f", null ],
    [ "fBeta", "a00071.html#a8afdafa92dcbcbb1578fe4630881b688", null ],
    [ "fDeltaT", "a00071.html#ad2058a1d6f7a36186332b45eba8fdcba", null ],
    [ "fGyroMeasError", "a00071.html#a61cd53b51b1d622e6c18519ee90433ce", null ],
    [ "xAEq", "a00071.html#a04141efc82718bfa6d26e9a4d071db60", null ],
    [ "xAtt", "a00071.html#a2fcc1adb588c74dd897b2b95aab38903", null ],
    [ "xSEq", "a00071.html#a2d8642cd6a48daacd6c1682afb771f9b", null ]
];