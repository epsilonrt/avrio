var a00266 =
[
    [ "iEepromLoadBlock", "a00266.html#ga2a87897e7c44819c808023d7bf112fb4", null ],
    [ "vEepromSaveBlock", "a00266.html#gadc7c40a950961aa57476ebe0bb6db579", null ]
];