var a00098 =
[
    [ "ucBindChannel", "a00098.html#a3e78d56f412a53d90e57cd67daf36fde", null ],
    [ "ucDataChannel", "a00098.html#a6de331ca1edd825169dcd684e29223f2", null ],
    [ "ucDataPnCode", "a00098.html#a5dd37ad76eac574bcfc17758d696cd84", null ],
    [ "ucStatus", "a00098.html#a774426093249ba77781caba366c5e3ba", null ]
];