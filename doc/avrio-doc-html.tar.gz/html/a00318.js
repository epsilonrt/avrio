var a00318 =
[
    [ "Configuration du réseau Nto1", "a00319.html", "a00319" ],
    [ "Transmission sur le réseau Nto1", "a00320.html", "a00320" ],
    [ "Réception sur le réseau Nto1", "a00321.html", "a00321" ],
    [ "WNET_BIND_CHANNEL", "a00318.html#ga18c74d730ad695675e393e4383dfcdc8", null ],
    [ "WNET_BIND_PNCODE", "a00318.html#gac103e5fea220ed581c9c76543ea43a01", null ],
    [ "WNET_INVALID_DEVICEID", "a00318.html#ga688f24597e560695dad8656045fbc5b9", null ],
    [ "WNET_MAJOR", "a00318.html#ga48fe1f8a99212f3891a9659707a4e6d8", null ],
    [ "WNET_MINOR", "a00318.html#ga0933cb92e4766f828900c1b9d1565643", null ],
    [ "WNET_VERSION", "a00318.html#ga074a19364c066c13ef0169de393122e4", null ],
    [ "eWNetErrorCode", "a00318.html#gad5c32ffd51d3a811eaf64b78d73b1490", [
      [ "WNET_SUCCESS", "a00318.html#ggad5c32ffd51d3a811eaf64b78d73b1490a8d24bb8e747aaed7081ab7178c0c91f9", null ],
      [ "WNET_TIMEOUT", "a00318.html#ggad5c32ffd51d3a811eaf64b78d73b1490aae26c48c1030a3d2c113a77596bf4790", null ],
      [ "WNET_CORRUPTED_PACKET_ERROR", "a00318.html#ggad5c32ffd51d3a811eaf64b78d73b1490ae37e1da1e2b2ccef277b457d5a3e5e27", null ]
    ] ],
    [ "eWNetError", "a00318.html#ga0a3d35ab774ec844fa2c933d0276d9a9", null ],
    [ "ucWNetRand", "a00318.html#ga8a26be10af0c93cf4baecadeed40d283", null ],
    [ "vWNetWaitIdle", "a00318.html#ga7c2bc73702540a69b1902e95987dc905", null ]
];