var a00095 =
[
    [ "pDataRate", "a00232.html#gaee930d1a3f3e09854442e7b6def2e320", null ],
    [ "pXtalAdjust", "a00232.html#gac165d070994dbdcb519ce99c8a0add4e", null ]
];