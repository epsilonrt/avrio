var a00259 =
[
    [ "xDcmAttitude", "a00066.html", [
      [ "fAtt", "a00066.html#ac9daba690b58964bb23ea13aad319c05", null ],
      [ "fMagHeading", "a00066.html#ac0b8a5182debc6002ba85b781bf66202", null ],
      [ "fRate", "a00066.html#a1af3fe760cd8ea7fa8370ab8e7797c99", null ]
    ] ],
    [ "DCM_NOT_READY", "a00259.html#gaa1491719f91d08d0400cde90e91945e4", null ],
    [ "iDcmInit", "a00259.html#gac2ea5500fa64ba65b6730ed9cda086cc", null ],
    [ "iDcmLoop", "a00259.html#gae822e282e3f8ac9f6268ebd12bdf4db0", null ],
    [ "pxDcmAttitude", "a00259.html#ga8e4122e3e25c1daeea3ca6e4e3852835", null ]
];