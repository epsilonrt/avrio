var a00096 =
[
    [ "Address", "a00232.html#gaf0adaf581e1342d1240241568e9f53a7", null ],
    [ "Value", "a00232.html#gab77e5e8c43a87f3bb8b7aa798bc95dfa", null ]
];