var a00327 =
[
    [ "Hub WirelessUSB iDwaRF", "a00328.html", "a00328" ],
    [ "Capteur WirelessUSB iDwaRF", "a00329.html", "a00329" ],
    [ "_MID", "a00051.html", [
      [ "sByte", "a00051.html#aec52780704165a5ed573f7d750ca1246", null ],
      [ "sNid", "a00051.html#ad1c6102b2db482111beb491832b2f0ab", null ],
      [ "u32Mid", "a00051.html#acb9bc9b68fc307eafbb50d766b162fe4", null ],
      [ "u8ChecksumSeed", "a00051.html#ac8896bd048de60e055d4716c7f7eb691", null ],
      [ "u8CrcSeed", "a00051.html#add943938b3cffa7770aa1ad413482426", null ],
      [ "u8Mid1", "a00051.html#a22a4c91d45c89570de5bb3fb17346099", null ],
      [ "u8Mid2", "a00051.html#abb88c3341c41dd6077a62545ed4ad5a6", null ],
      [ "u8Mid3", "a00051.html#ad91a7dff7c59b5f4d20134bdc7762481", null ],
      [ "u8Mid4", "a00051.html#af5f1aa932f211036158d607367cc61c8", null ]
    ] ],
    [ "IDWARF_BACKDATA_SIZE", "a00327.html#ga2e1ce08ceb330e093cbcf3c5f5224166", null ],
    [ "IDWARF_PAYLOAD_SIZE", "a00327.html#ga25ba9e21a6c1edc58a705f9fb8411ede", null ],
    [ "IDWARF_SLEEP_TIME", "a00327.html#ga77effa905002fcfb91f4c2ed72960445", null ],
    [ "I16", "a00327.html#ga393f3d55b6dd420b4ec0482d11fb0d9b", null ],
    [ "I32", "a00327.html#ga2f1a62071dd7dc3f6ef85c1b7612dc35", null ],
    [ "I8", "a00327.html#ga33c92dd47950aa8c1d6df7e1c163e5a6", null ],
    [ "MID", "a00327.html#gaadbb32d2daa5cdd157a86e3d92f23f2d", null ],
    [ "U16", "a00327.html#ga0a0a322d5fa4a546d293a77ba8b4a71f", null ],
    [ "U32", "a00327.html#ga696390429f2f3b644bde8d0322a24124", null ],
    [ "U8", "a00327.html#gaa63ef7b996d5487ce35a5a66601f3e73", null ],
    [ "PACKET_TYPES", "a00327.html#ga3ac2f53a6db3f2414db8091758ad890f", [
      [ "FIXED_DATA_PACKET", "a00327.html#gga3ac2f53a6db3f2414db8091758ad890faad8c457aafeb99a6622d23b72c4370cd", null ],
      [ "VARIABLE_DATA_PACKET", "a00327.html#gga3ac2f53a6db3f2414db8091758ad890fac2411b329ffe928f93dc0030fd3e5af7", null ]
    ] ],
    [ "PROTOCOL_STATUS", "a00327.html#ga7e421c1ba14c79eb5d8ccbd7ea44cffb", null ],
    [ "avrSleep", "a00327.html#ga1ab8db3ee7cad33f41b29c87f1ef3a24", null ],
    [ "rfInit", "a00327.html#gabafd325193df7d07f2c94b40ae7c9724", null ],
    [ "rfProcessAll", "a00327.html#ga284181d3fe49a8f027874bb287387a03", null ]
];