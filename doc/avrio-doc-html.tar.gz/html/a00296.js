var a00296 =
[
    [ "SERIAL_SW_FRAME_ERROR", "a00296.html#gaee0c72e5be444223ea1139e5e56b0010", null ],
    [ "SERIAL_SW_RX_BUFFER_FULL", "a00296.html#ga1c3b7a60f1273aa9c7185397aaaac24c", null ],
    [ "SERIAL_SW_RX_BUFFER_OVERFLOW", "a00296.html#gafeb99330c72767328c390ccdee27fd66", null ],
    [ "SERIAL_SW_TX_BUFFER_FULL", "a00296.html#gaa72349daa44d307aeea6515212c4cd5d", null ],
    [ "iSerialSwGetChar", "a00296.html#gaf4d1d9fa7822f3190d4a6457cb5da1f8", null ],
    [ "ucSerialSwGetFlags", "a00296.html#gace7f682e17fc2e1b77c93dbc8dd28895", null ],
    [ "usSerialSwHit", "a00296.html#ga14b47447403c9249cd7950d1655455d4", null ],
    [ "vSerialSwDisable", "a00296.html#ga4fbd5dbe85167948157a2daf7d55304e", null ],
    [ "vSerialSwEnable", "a00296.html#ga3b8c0767fa5801733c4d7b68f0c1d680", null ],
    [ "vSerialSwInit", "a00296.html#gad2928df4e8e46784bb49cfdcab797a4c", null ],
    [ "vSerialSwPutChar", "a00296.html#ga81692015c3f638d907eeb8972509b335", null ],
    [ "vSerialSwPutString", "a00296.html#gaac980c601c9a0c226f68921e761ced44", null ],
    [ "xSerialSwReady", "a00296.html#ga3838d50eed007c752eaec78fe79c2c75", null ],
    [ "xSerialSwPort", "a00296.html#ga984c40c9f199f1c4831c260ed61c517a", null ]
];