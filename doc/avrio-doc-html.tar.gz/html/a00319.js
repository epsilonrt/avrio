var a00319 =
[
    [ "xXBeePkt", "a00108.html", [
      [ "data", "a00108.html#ad51b9fada60826b3b69748da371306ed", null ],
      [ "hdr", "a00108.html#a9329385eb8ced59148bf777add9a7f0b", null ],
      [ "type", "a00108.html#aa11d4a309a3bd61aa92e291ab02848ff", null ]
    ] ],
    [ "xXBeePktHdr", "a00109.html", [
      [ "len", "a00109.html#abbece38c7bfc3e3ceb7c544aa33ffe84", null ],
      [ "start", "a00109.html#a1a2c4348b68f45e6ecfd59407358ed6e", null ]
    ] ],
    [ "pvXBeeUserContext", "a00319.html#gabd4be3dcb3e79200981599ea87e088f9", null ],
    [ "iXBeeRxCB", "a00319.html#ga1f1e8d20aca6c08a7ff7d699f2ac7117", null ],
    [ "xXBee", "a00319.html#ga310737edafbe2774d268062dd177b023", null ],
    [ "eXBeeCbType", "a00319.html#ga3cb62a2eb6fa94983d478fcd9a7ab0c3", null ],
    [ "eXBeePktType", "a00319.html#ga50bd3cc130200c4beb362a8c890e3325", null ],
    [ "__attribute__", "a00319.html#gaaa87fa97630276b530013bdd9586e5e3", null ],
    [ "bXBeePktAddressIsEqual", "a00319.html#gad2293d66ecd7c228e56f1a73ad41e19a", null ],
    [ "iXBeePktDataLen", "a00319.html#gaf0cd0ca4324b404af8275be6bcfdf0d4", null ],
    [ "iXBeePktDiscovery", "a00319.html#ga55cf7830d73bc06f4f0d00067c45b1cc", null ],
    [ "iXBeePktDst16", "a00319.html#ga8d0650c5f0f86c17a6b9388c65e7f963", null ],
    [ "iXBeePktFrameId", "a00319.html#ga5249f17f0418e8acd30b5c9e538b4c63", null ],
    [ "iXBeePktRetry", "a00319.html#ga3a4cea042fef15cb1f165035365c1402", null ],
    [ "iXBeePktStatus", "a00319.html#ga537f477dc68932ec7e2495e0bb737ac6", null ],
    [ "iXBeePoll", "a00319.html#gab494d235a6fd6ebc8d8152b8cc71274a", null ],
    [ "iXBeeSend16", "a00319.html#ga6a331aded3e622068c82fc2d579a375c", null ],
    [ "iXBeeSend64", "a00319.html#ga57f6d684679de828c0e91b8264091fb7", null ],
    [ "iXBeeSendAt", "a00319.html#ga97ad61dd078e75256c2845e1c0527a5f", null ],
    [ "iXBeeSendRemoteAt", "a00319.html#ga5b844482199fae8593dbbad337cf7477", null ],
    [ "iXBeeZbSend", "a00319.html#ga83105b4cbce519abcc2c36c2b82fbf0e", null ],
    [ "iXBeeZbSendToCoordinator", "a00319.html#ga691e139029fc195519f0b7a18db29c64", null ],
    [ "pucXBeeAddr16Unknown", "a00319.html#gafbf311e68bd650ada3bc4e8f721149d5", null ],
    [ "pucXBeeAddr64Broadcast", "a00319.html#ga377108b66188c3d47748db187998cc6f", null ],
    [ "pucXBeeAddr64Coordinator", "a00319.html#gab24cc66d94e932eec2b186bff24dee5a", null ],
    [ "pucXBeeAddr64Unknown", "a00319.html#ga378d7dbc22e4b627e92f77726855d01e", null ],
    [ "pucXBeePktAddrSrc16", "a00319.html#gad69860d6fd59ec30de7e1c690b38012e", null ],
    [ "pucXBeePktAddrSrc64", "a00319.html#gaa2dc1fda6fe4c9f7aeea353c36012f8a", null ],
    [ "pucXBeePktData", "a00319.html#gabb361758433b22396e195a7d328ed3c1", null ],
    [ "pvXBeeAllocPkt", "a00319.html#gab967fabfb089937db060d80188f864a0", null ],
    [ "ucXBeePktType", "a00319.html#gab95b90438bef64637ad4bb96c0a4df16", null ],
    [ "vXBeeFreePkt", "a00319.html#ga6cbfd95a8476be0b673b2dc3993446e2", null ],
    [ "vXBeeInit", "a00319.html#ga4ccc97bce239aaaa7ce6f3462a541bf5", null ],
    [ "vXBeeSetCB", "a00319.html#ga716d5f17df4d46ff4f023ed3fa8aaf09", null ]
];