var a00232 =
[
    [ "Hub WirelessUSB", "a00315.html", "a00315" ],
    [ "Coupleur WirelessUSB CYWUSB6935", "a00317.html", "a00317" ],
    [ "Modélisation d'un réseau WirelessUSB", "a00318.html", "a00318" ],
    [ "Paquet réseau WirelessUSB Nto1", "a00322.html", "a00322" ],
    [ "Capteur Nto1 WirelessUSB", "a00323.html", "a00323" ],
    [ "WDEV_BUSY", "a00317.html#ggabd165a063b532f7b545cc12f31b8f95caa01076edc4e3a15dc150e4ab4b13ce6f", null ],
    [ "WDEV_IDLE", "a00317.html#ggabd165a063b532f7b545cc12f31b8f95ca9bb20fa3fdc796fca469d85d5a23f334", null ],
    [ "WDEV_RX", "a00317.html#ggabd165a063b532f7b545cc12f31b8f95ca7e4ae9242c0daf62b9de02fcb4da39d0", null ],
    [ "WDEV_TX", "a00317.html#ggabd165a063b532f7b545cc12f31b8f95ca3e946cfbdb077a6e79a69a157d062b2a", null ],
    [ "WDEV_TXBUSY", "a00317.html#ggabd165a063b532f7b545cc12f31b8f95ca7641c6eb55609a7f809327bdad38d69b", null ],
    [ "Address", "a00232.html#gaf0adaf581e1342d1240241568e9f53a7", null ],
    [ "pData", "a00232.html#gac9b1acf15057c8aa08f61f8140707bf9", null ],
    [ "pDataRate", "a00232.html#gaee930d1a3f3e09854442e7b6def2e320", null ],
    [ "pXtalAdjust", "a00232.html#gac165d070994dbdcb519ce99c8a0add4e", null ],
    [ "Regs", "a00232.html#gaaa56221d93094b59eb1be0a496108463", null ],
    [ "Size", "a00232.html#gae52d47207df40268311381159adaa65c", null ],
    [ "Value", "a00232.html#gab77e5e8c43a87f3bb8b7aa798bc95dfa", null ],
    [ "xLen", "a00232.html#ga68a6973df2cefb0a312ca360bdb94f1c", null ],
    [ "xSize", "a00232.html#ga6b48bd65454b13c0567d5a7e7e70ea09", null ]
];