var a00089 =
[
    [ "eFlag", "a00089.html#a30cc76020e33ff13dd3bce17a73db12b", null ],
    [ "pxInputStream", "a00089.html#a2a09d7dff4acc0fa024986748bf9c5ff", null ],
    [ "pxMenu", "a00089.html#aad24c525c3d003ce9b1a474c5c6adc0b", null ],
    [ "pxOuputStream", "a00089.html#ac2c7edc7ce69bd75a281a2ea3d710789", null ],
    [ "xPos", "a00089.html#a8c950ccdabe66b419e55fde34089d1c6", null ],
    [ "xSize", "a00089.html#ab8342064a4055a005e1c837facf31d72", null ]
];