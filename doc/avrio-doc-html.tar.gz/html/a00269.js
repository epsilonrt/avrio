var a00269 =
[
    [ "HDLC_ESC", "a00269.html#ga0c1dbbb5fe58c8fdf4eca0d9f6256bd7", null ],
    [ "HDLC_FLAG", "a00269.html#ga7dfaac00ac4dc67fd47f2cbdf51d5c72", null ],
    [ "HDLC_RESET", "a00269.html#ga69a2c8271c865acf4cfa1c1d8ee9443e", null ]
];