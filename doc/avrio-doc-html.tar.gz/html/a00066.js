var a00066 =
[
    [ "fAtt", "a00066.html#ac9daba690b58964bb23ea13aad319c05", null ],
    [ "fMagHeading", "a00066.html#ac0b8a5182debc6002ba85b781bf66202", null ],
    [ "fRate", "a00066.html#a1af3fe760cd8ea7fa8370ab8e7797c99", null ]
];