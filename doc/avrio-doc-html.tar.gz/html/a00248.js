var a00248 =
[
    [ "xMessage", "a00077.html", null ],
    [ "xMessageQueue", "a00078.html", null ],
    [ "xMessage", "a00248.html#gae477b9333f98af15b6e5c5f7feb39a7d", null ],
    [ "xMessageQueue", "a00248.html#ga35b5eb2477182e808b3a945f638e9e37", null ],
    [ "pxAvrXRecvMessage", "a00248.html#gaa8b2a724ab9c39c0634fedb3b2c61f50", null ],
    [ "pxAvrXWaitMessage", "a00248.html#gab49f9ec06f98e96926449f7766e206fb", null ],
    [ "vAvrXAckMessage", "a00248.html#ga357db87daafc1dbd17860959c9b08168", null ],
    [ "vAvrXIntSendMessage", "a00248.html#ga7e45f285005cf0f7df5288ad2ab67df3", null ],
    [ "vAvrXSendMessage", "a00248.html#ga2d9909b4a190308abb9bff068d559226", null ],
    [ "vAvrXWaitMessageAck", "a00248.html#ga5073815e376ecf658737146a2ec1988c", null ],
    [ "xAvrXTestMessageAck", "a00248.html#ga69c031371fada6408b2cb28a7ba6e1e6", null ]
];