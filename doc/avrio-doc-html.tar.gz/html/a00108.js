var a00108 =
[
    [ "hdr", "a00108.html#a3991964bd0abeef796f26ff259f15350", null ],
    [ "status", "a00108.html#a8223df323335ff0e7571ab47652700b2", null ],
    [ "type", "a00108.html#a04362132a8876cebad75edfef2474457", null ]
];