var a00310 =
[
    [ "Wusb_sensor_database", "a00311.html", "a00311" ],
    [ "xWHubConfig", "a00097.html", [
      [ "ucBindChannel", "a00097.html#a3e78d56f412a53d90e57cd67daf36fde", null ],
      [ "ucDataChannel", "a00097.html#a6de331ca1edd825169dcd684e29223f2", null ],
      [ "ucDataPnCode", "a00097.html#a5dd37ad76eac574bcfc17758d696cd84", null ],
      [ "ucStatus", "a00097.html#a774426093249ba77781caba366c5e3ba", null ]
    ] ],
    [ "xWHubMessage", "a00098.html", [
      [ "pucData", "a00098.html#a1c4bd31d966af58bde192da44d3881e3", null ],
      [ "ucDataLength", "a00098.html#a798fd1205924ac762bf7b401b0a8fe7b", null ],
      [ "ucId", "a00098.html#aa16d328ec6d9597d0cf5efc43825f1f3", null ],
      [ "ucStatus", "a00098.html#aed71710beeac616ab0dd801dabea5795", null ],
      [ "usDeviceId", "a00098.html#aa2142439e57fb14ba5c89175dd06c30e", null ]
    ] ],
    [ "xWHubService", "a00099.html", [
      [ "ucRssiCounter", "a00099.html#a9059b865e3586edcec0bbdfe24ca41ce", null ],
      [ "xModeMutex", "a00099.html#a575f380751d40ee77c1ca0b87da396df", null ],
      [ "xTask", "a00099.html#a10fe2d9a638887211c697f775da5441b", null ]
    ] ],
    [ "xWusbHub", "a00103.html", [
      [ "ucFlag", "a00103.html#aae046d837110de69167f1a2093546085", null ],
      [ "ucNoiseThreshold", "a00103.html#aa1f3eedab2484eb1ef25440acdb19f14", null ],
      [ "xConfig", "a00103.html#a20866512ddd6097dceb554659e81b930", null ],
      [ "xMsg", "a00103.html#ae394ba9b76061731ff411dd878689956", null ],
      [ "xService", "a00103.html#ac37c46d90b6f6e9efeee5d08c1919c06", null ]
    ] ],
    [ "eWHubMsgId", "a00310.html#ga6f843bd66ee0e5ab9fba431c38939af3", null ],
    [ "eWHubMsgStatus", "a00310.html#ga1c3a642184d81bd80ca5d09145a1fa11", null ],
    [ "eWHubStatus", "a00310.html#ga9a526f8765788fa94eeecb1ed52165f9", [
      [ "WHUB_EEPROMBLANK", "a00310.html#gga9a526f8765788fa94eeecb1ed52165f9abd09b21786bdb377bd38977f1ea621c9", null ],
      [ "WHUB_AUTOBIND", "a00310.html#gga9a526f8765788fa94eeecb1ed52165f9ad3017b92869a78866129bc07751d03c5", null ],
      [ "WHUB_SEEDEDBIND", "a00310.html#gga9a526f8765788fa94eeecb1ed52165f9a22e73cf72e924258cb764880fa5e9476", null ],
      [ "WHUB_SEARCHCHANNEL", "a00310.html#gga9a526f8765788fa94eeecb1ed52165f9a59daec7327f0bb7f4680e6f5da9aee76", null ],
      [ "WHUB_BACKDATA", "a00310.html#gga9a526f8765788fa94eeecb1ed52165f9aa226df23338df3acca84740a7c807d6f", null ],
      [ "WHUB_NODEBOUND", "a00310.html#gga9a526f8765788fa94eeecb1ed52165f9a1f320b1979c6b2044741404bca6afe9f", null ],
      [ "WHUB_BIND", "a00310.html#gga9a526f8765788fa94eeecb1ed52165f9a1bd07bdad2c2d4056dbc3bdba5355097", null ],
      [ "WHUB_CONFIGSAVED", "a00310.html#gga9a526f8765788fa94eeecb1ed52165f9a954ded8689fa565d077a7d93c36568ac", null ]
    ] ],
    [ "WSDBASE_BACKDATA", "a00311.html#gga24e056fa6367a2174825c20af2f53da0a94f30b358118c7264a964dd34d41fe1b", null ],
    [ "WSDBASE_NOTIFY", "a00311.html#gga24e056fa6367a2174825c20af2f53da0adf198fdbcb2881386a572054fd515d86", null ],
    [ "WSDBASE_RX_SEQN", "a00311.html#gga24e056fa6367a2174825c20af2f53da0ad91f0ae65ee4bfccbf67d1dbd8bacafb", null ],
    [ "WSDBASE_TX_SEQN", "a00311.html#gga24e056fa6367a2174825c20af2f53da0a512eaf8d690dc4a6c789cfd96177fb8d", null ],
    [ "WSDBASE_VALID_DID", "a00311.html#gga24e056fa6367a2174825c20af2f53da0a133977457680fc67d4adf80d40a75c60", null ],
    [ "iWHubInit", "a00310.html#ga6f0840daba1b0b76bbaa950bbd26f42d", null ],
    [ "pucWHubMid", "a00310.html#ga902d3ac0053d812ae18458be83dc0e8e", null ],
    [ "pxWHubLoop", "a00310.html#gad4efcf0aacf4dff4f215c770afd15502", null ],
    [ "ucWHubBindChannel", "a00310.html#ga9d155fda3054cac7ee51df7e0b360257", null ],
    [ "ucWHubDataChannel", "a00310.html#ga43cd353ee718f9174df6b28ce5eead66", null ],
    [ "ucWHubDataPnCode", "a00310.html#ga48e78cb1441b20b42fbb54f85c6aa0df", null ],
    [ "ucWHubNodeDataLength", "a00310.html#ga0d91d7aa8e52b64c96f1c69d01fcfb87", null ],
    [ "ucWHubStatus", "a00310.html#ga0ae3dc23654257b305f8359a122ac45b", null ],
    [ "ulWHubNodeMid", "a00310.html#ga73bc958e1201d45be53adb0d1975eaf4", null ],
    [ "usWHubDeleteAllNodes", "a00310.html#ga008e4c12835eaacadec7ae7cfc4ae3c6", null ],
    [ "usWHubMaxNumberOfNodes", "a00310.html#ga4ab3575159409b67041c00b643e2875a", null ],
    [ "usWHubNumberOfNodes", "a00310.html#ga67163f137c0ab3badcf3528598f7537a", null ],
    [ "vWHubNodeSetData", "a00310.html#gafe0826d25b29796a8a64c19c64028c59", null ],
    [ "vWHubNodeSetFlag", "a00310.html#ga78b5b65343ad0541ed1ed186adcc963a", null ],
    [ "vWHubSetMid", "a00310.html#ga62bbcc19654ddcac3ec432548e733f8c", null ],
    [ "vWHubSetStatusFlag", "a00310.html#gafce3aa2e6b7dde5da6da09821c68a1a0", null ],
    [ "vWHubToggleStatusFlag", "a00310.html#gaa23ab862f278d65f9708c1c191510dcb", null ],
    [ "WHubNodeDelete", "a00310.html#gace27b082a450e4fbf3b32401f07ad4cc", null ],
    [ "xWHubNodeFlag", "a00310.html#ga47f3395dc23f68614c4401f92dc6f4d9", null ],
    [ "xWHubSetDataChannel", "a00310.html#ga5b402c67c1ff86c603152f494fec95ef", null ],
    [ "xWHubSetDataPnCode", "a00310.html#gaa4362de832bb8e980e6a9d15778d7a21", null ],
    [ "xWHubStatusFlag", "a00310.html#ga90ddaaf83521e0a065b5e9cf8fa5d480", null ],
    [ "pucBackData", "a00310.html#ga03117ab349aad42286598a88e33aa4cf", null ],
    [ "ucBackDataLength", "a00310.html#gaf0574e568a43013297a246f6f5e59cdb", null ],
    [ "ucFlag", "a00310.html#ga822b1a20c6356f88dae412b0a3cf59bd", null ],
    [ "ulMid", "a00310.html#ga8352fd35c25e5a810e7c52252ff5fd41", null ],
    [ "usNextFreeDeviceId", "a00310.html#gacecc52ba3937a0cef0fe6e5e7b202c56", null ],
    [ "usSize", "a00310.html#gaf8cf9ba8e1dcc70801a6399e13450895", null ]
];