var a00275 =
[
    [ "Définitions pour la configuration du driver clavier", "a00263.html", null ],
    [ "KEY_DOWN", "a00275.html#ga203163bc0189184a1de6ca8d1e53c6bf", null ],
    [ "KEY_ENTER", "a00275.html#gabaee5edb96e542206ae6c8102ac228af", null ],
    [ "KEY_HOME", "a00275.html#gaf6806366178266b3eaf1fb16f991cbee", null ],
    [ "KEY_LEFT", "a00275.html#gaf4d1b8a2912354646c74cf36c69f8223", null ],
    [ "KEY_RIGHT", "a00275.html#ga004194639b9ad76cea01d9e93716d4d6", null ],
    [ "KEY_UP", "a00275.html#gafa086fc916a81e7fd348ec00cf786916", null ],
    [ "cKeybGetChar", "a00275.html#ga6015c7e97cd995bac6d095e51c76620c", null ],
    [ "usKeybHit", "a00275.html#ga4595816010c1af2c600f74ea56ecdd8a", null ],
    [ "vKeybFlush", "a00275.html#ga97187494724c7d1b591e00f8779ac9b6", null ],
    [ "vKeybInit", "a00275.html#gadf3e79d370deb6c261f4f7011f1a9b3c", null ],
    [ "xKeyb", "a00275.html#ga83341fb792698453ae3b287be6ec29bc", null ]
];