var a00247 =
[
    [ "AVRX_DONE", "a00247.html#gad3f047d5c5e08eb3facb3d3d8b51b41a", null ],
    [ "AVRX_PEND", "a00247.html#ga6ff252e7ea0a89f00bb3a66721acbbf2", null ],
    [ "AVRX_WAIT", "a00247.html#ga60b4f8deaf496adbf6ced39f77194cea", null ],
    [ "xSem", "a00247.html#gae4310679e71d065206f65c9aff867d8e", null ],
    [ "vAvrXIntSetSemaphore", "a00247.html#ga580594d6d9c4cb683274b8b4a2111058", null ],
    [ "vAvrXResetObjectSemaphore", "a00247.html#gaadde8ffcdb261531d4947f8c3bc9a5b5", null ],
    [ "vAvrXResetSemaphore", "a00247.html#gad2ccd67d4c8abcdd2c7b68628a746169", null ],
    [ "vAvrXSetSemaphore", "a00247.html#gaa4406cdc13c5f5dfc4be6ae8a3f96694", null ],
    [ "vAvrXWaitSemaphore", "a00247.html#ga99e322c20a7a635c90c45708320f9db4", null ],
    [ "xAvrXIntTestSemaphore", "a00247.html#gab94278f1a7db4e7e7c69e913bfb73847", null ],
    [ "xAvrXTestSemaphore", "a00247.html#gad74b0102e1cf4f35e76d594e3bbb4a7e", null ]
];