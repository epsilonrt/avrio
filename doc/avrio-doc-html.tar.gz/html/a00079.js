var a00079 =
[
    [ "length", "a00079.html#a4262142333169a606fbf2a08d77a75cc", null ],
    [ "pitch", "a00079.html#a580255e9f19354125a4bcd96f5624de4", null ]
];