var a00104 =
[
    [ "pData", "a00229.html#gac9b1acf15057c8aa08f61f8140707bf9", null ],
    [ "xLen", "a00229.html#ga68a6973df2cefb0a312ca360bdb94f1c", null ],
    [ "xSize", "a00229.html#ga6b48bd65454b13c0567d5a7e7e70ea09", null ]
];