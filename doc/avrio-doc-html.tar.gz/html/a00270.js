var a00270 =
[
    [ "xHeap", "a00067.html", [
      [ "freelist", "a00067.html#a21f3bce46f329643f7834b8c765a62b7", null ]
    ] ],
    [ "HEAP_DEFINE_BUF", "a00270.html#gade2fd903de6ec7b63bd94c3d69e16738", null ],
    [ "xHeap", "a00270.html#ga1eb0aba836d27528b85d8eedd28b8e18", null ],
    [ "pvHeapAllocMem", "a00270.html#gadf075a7ba2f8384e4658e5a29947ec36", null ],
    [ "pvHeapCalloc", "a00270.html#ga0fd90e0c754699ca1c888cdbca813f22", null ],
    [ "pvHeapMalloc", "a00270.html#ga8489efb253c4002ecc3811541ef9b7da", null ],
    [ "ulHeapFreeSpace", "a00270.html#ga8210629a2cdfd05259509f47e123cbd6", null ],
    [ "vHeapFree", "a00270.html#ga0f55b0718b3885961625844444951302", null ],
    [ "vHeapFreeMem", "a00270.html#ga0578f0ba26725eca0abfb1aa1ee25c60", null ],
    [ "vHeapInit", "a00270.html#ga0baa7074c7be806fa75574412057eb1f", null ]
];