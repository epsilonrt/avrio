var a00309 =
[
    [ "TWI_GENCALL", "a00309.html#gafca33377abaf0fe848639210c7675b35", null ],
    [ "TWIFRAME_DECLARE", "a00309.html#gab0d100a7790177a3fbd2dfb2ce2cf963", null ],
    [ "TWIFRAME_STATIC_DECLARE", "a00309.html#ga49adebaee51038213e8f59f43d45de8d", null ],
    [ "eTwiSlaveRxCB", "a00309.html#gae22a093bd73f6d19e410df1a4771862e", null ],
    [ "eTwiSlaveTxCB", "a00309.html#ga8bdd1ee8eb8f67eb1e6d67af6b794e60", null ],
    [ "vTwiSetDeviceAddress", "a00309.html#gaec022c2d689c1d8aeaaf12f02d1d7fe5", null ]
];