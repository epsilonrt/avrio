var a00305 =
[
    [ "Mode maître", "a00306.html", null ],
    [ "Mode esclave", "a00307.html", null ]
];