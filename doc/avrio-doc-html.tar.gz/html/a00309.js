var a00309 =
[
    [ "Configuration du module I2C", "a00310.html", "a00310" ],
    [ "Bus I2C en mode maître", "a00313.html", "a00313" ],
    [ "Bus I2C en mode esclave", "a00314.html", "a00314" ],
    [ "xTwiFrame", "a00094.html", [
      [ "pxData", "a00233.html#ga5b7c9b97ec897f1daca558a3c38c64f1", null ],
      [ "xAddr", "a00233.html#ga969453b8620c2b3cbf743c8146cfc5a7", null ],
      [ "xLen", "a00233.html#ga862e5b94d2d295f11f320e250d83999b", null ]
    ] ],
    [ "xTwiDeviceAddr", "a00309.html#ga906cdb7d236ef020cd716f4e6a748fac", null ],
    [ "xTwiLength", "a00309.html#ga2085b1b8848cc20fbe95b2759c95995d", null ],
    [ "eTwiStatus", "a00309.html#gadae8b1d38eeb34e3cdf21f19d957f772", [
      [ "TWI_SUCCESS", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772a08f449764a2022571435668382b657e4", null ],
      [ "TWI_STATUS_TX", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772a8df0411a403283ffe82e17df9ff4f270", null ],
      [ "TWI_STATUS_RX", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772a968347013ca3ba34ac30b00f0d37a61c", null ],
      [ "TWI_STATUS_BUSY", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772ab8a273b2929517a26fa4a4435c24fc3e", null ],
      [ "TWI_STATUS_LCALL", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772a4496875b8c45505640105e5c978f4415", null ],
      [ "TWI_STATUS_GCALL", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772a3e4ac0ac120fd7fc8693b3defccae8d4", null ],
      [ "TWI_STATUS_TXBUFFER_EMPTY", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772a218985289d9d2431841321a1f06d89b8", null ],
      [ "TWI_STATUS_ARB_LOST", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772a7eedaf6fcf0f77531c52a7bf89c5a72a", null ],
      [ "TWI_ERROR_DATA_NACK", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772ab1059b5901bf7361817cad4f196dfa5b", null ],
      [ "TWI_ERROR_ADDR_NACK", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772a337cffdb4ccada8e3c4fad6296d39570", null ],
      [ "TWI_ERROR_ILLEGAL_START_STOP", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772a60c16db8d02b59e1912313162a487055", null ],
      [ "TWI_ERROR_INVALID_SPEED", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772ad77d942242f650ef0271c799aecdd57e", null ],
      [ "TWI_ERROR_INVALID_LENGTH", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772a477aa0a06aab41912fa287805d9ecc99", null ],
      [ "TWI_ERROR_BUFFER_FULL", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772aa41987293dc0fee685cb54016a09f552", null ],
      [ "TWI_ERROR_TIMEOUT", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772a3772b023d78b7fb98b7d803f5f18d1b3", null ],
      [ "TWI_ERROR_ILLEGAL_CODE", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772a12b55a7c88208820e4af740263b48e66", null ],
      [ "TWI_ERROR_INVALID_DEVICE", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772a2c6f63022f54ddf9f383d8c9ffcfc111", null ],
      [ "TWIMEM_ERROR_READ", "a00309.html#ggadae8b1d38eeb34e3cdf21f19d957f772adbd66e6beeb57b144198900ab37e7b2b", null ]
    ] ],
    [ "bTwiIsBusy", "a00309.html#ga1912ba140fe3192a24fcad589756857c", null ],
    [ "vTwiInit", "a00309.html#gae648ead542ee0a9d85945c1e2dca62bb", null ]
];