var a00089 =
[
    [ "iColumn", "a00089.html#ab3d81572ef56e9ece500b454ac93fda0", null ],
    [ "iLine", "a00089.html#a2c622d008a063f80c4932d986d945be0", null ]
];