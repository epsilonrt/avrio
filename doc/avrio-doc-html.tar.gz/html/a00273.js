var a00273 =
[
    [ "xImu6dFilter", "a00072.html", [
      [ "bFirstUpdate", "a00072.html#a9dad3f115202f651c6c787d39d1f5b5f", null ],
      [ "fBeta", "a00072.html#a8afdafa92dcbcbb1578fe4630881b688", null ],
      [ "fDeltaT", "a00072.html#ad2058a1d6f7a36186332b45eba8fdcba", null ],
      [ "fGyroMeasError", "a00072.html#a61cd53b51b1d622e6c18519ee90433ce", null ],
      [ "xAEq", "a00072.html#a04141efc82718bfa6d26e9a4d071db60", null ],
      [ "xAtt", "a00072.html#a2fcc1adb588c74dd897b2b95aab38903", null ],
      [ "xSEq", "a00072.html#a2d8642cd6a48daacd6c1682afb771f9b", null ]
    ] ],
    [ "fImu6dPitch", "a00273.html#gabc115ee5636e446ab719b739d6b53c65", null ],
    [ "fImu6dRoll", "a00273.html#gac69818ee4d892426e7d00960e0fb703a", null ],
    [ "fImu6dYaw", "a00273.html#gab89836d66bfd8e6b5470aaba6d411371", null ],
    [ "vImu6dComputeEuler", "a00273.html#ga3c0f57a86019e89829a3844303cfd49d", null ],
    [ "vImu6dInit", "a00273.html#gad06a8e5e12fbc1606e61e4eb926796b3", null ],
    [ "vImu6dReset", "a00273.html#gae682a0a0083f6dcc43109d5e12fbac00", null ],
    [ "vImu6dUpdateFilter", "a00273.html#ga49925eeba8e7e22127cdaec9b16c5b43", null ]
];