var a00099 =
[
    [ "pucData", "a00099.html#a1c4bd31d966af58bde192da44d3881e3", null ],
    [ "ucDataLength", "a00099.html#a798fd1205924ac762bf7b401b0a8fe7b", null ],
    [ "ucId", "a00099.html#aa16d328ec6d9597d0cf5efc43825f1f3", null ],
    [ "ucStatus", "a00099.html#aed71710beeac616ab0dd801dabea5795", null ],
    [ "usDeviceId", "a00099.html#aa2142439e57fb14ba5c89175dd06c30e", null ]
];