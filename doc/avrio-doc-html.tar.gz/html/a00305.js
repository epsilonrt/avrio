var a00305 =
[
    [ "vSwitchInit", "a00305.html#gaad9d3c533d489e91d069fe3907320218", null ],
    [ "xSwitchGet", "a00305.html#gaf642f0667ce784a5e13093c185ff6474", null ],
    [ "xSwitch", "a00305.html#gae20b2114922a3f6ac617cad75eb6a6a3", null ]
];