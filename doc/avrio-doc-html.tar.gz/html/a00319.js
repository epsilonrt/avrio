var a00319 =
[
    [ "xWNetConfig", "a00101.html", [
      [ "ucChannel", "a00101.html#a576724af66ca23ebab68263cc24a83f4", null ],
      [ "ucChecksumSeed", "a00101.html#ae1f82a6703eac4c24bba8f182c77a200", null ],
      [ "ucCrcSeed", "a00101.html#acaf22bd968685ffdf258f4c8159e0ae8", null ],
      [ "ucPnCode", "a00101.html#a86a2994f17ff8e05cb96549d39c75804", null ],
      [ "ucStatus", "a00101.html#a86dc1fc7a42754442184117e8ed124cc", null ]
    ] ],
    [ "eWNetStatusCode", "a00319.html#ga8c41da8f239b1f8b2ebf36db8adc172e", [
      [ "WNET_EEPROMBLANK", "a00319.html#gga8c41da8f239b1f8b2ebf36db8adc172eaf0395ec83ba8c60874c0109ee1086852", null ],
      [ "WNET_SINGLEBYTE", "a00319.html#gga8c41da8f239b1f8b2ebf36db8adc172eacbb8a906e27acfcd5ecd9f17dcf993ba", null ]
    ] ],
    [ "pxWNetCurrentConfig", "a00319.html#ga41a31d47f2285a6e440c082d6cf11251", null ],
    [ "ucWNetChannel", "a00319.html#ga83830908df83a4b64a5a8338218bd945", null ],
    [ "ucWNetChecksumSeed", "a00319.html#gae92b5b31149dc80c020b42d143b09003", null ],
    [ "ucWNetCrcSeed", "a00319.html#gaff9bc18d7ed8566a0355748f6640f635", null ],
    [ "ucWNetNumberOfChannelsUsed", "a00319.html#ga68b07f6698156722cfdd883b57f21883", null ],
    [ "ucWNetNumberOfPnCodes", "a00319.html#ga3ae5141f740906d536e7c6b19ca3a859", null ],
    [ "ucWNetNumberOfSubsets", "a00319.html#gaa9d4dce9d266ffbb80ab7a264c47532a", null ],
    [ "ucWNetPnCode", "a00319.html#ga4dc11189fdec1b9fd65fb58c47e792a6", null ],
    [ "vWNetGoToNextChannel", "a00319.html#ga9cf448604ee85c4b09c893f1ba2c6b00", null ],
    [ "vWNetInit", "a00319.html#ga7ef925e28327e07286ed68335d18a902", null ],
    [ "vWNetSaveConfigToEEPROM", "a00319.html#gabbf585198e7ef13c5c5b6d75517bf093", null ],
    [ "vWNetSetChecksumSeed", "a00319.html#ga62526a290377ce7aa60974f01534b684", null ],
    [ "vWNetSetConfig", "a00319.html#gabc2e158a8ef159cef683218e259c7f82", null ],
    [ "vWNetSetCrcSeed", "a00319.html#gab6b49acf8e6939b07712bf1b4af5a485", null ],
    [ "vWNetSetSingleByteDeviceId", "a00319.html#ga3e2cc4fc4f4182c746cdb00fc8675713", null ],
    [ "vWNetSetStatus", "a00319.html#ga3d71d9b7156300300beeb8b4e02ecdd2", null ],
    [ "vWNetToggleStatus", "a00319.html#gaba247b54a346f0fcd0ae529e52529e71", null ],
    [ "xWNetSetChannel", "a00319.html#gac8e8387714a335d135b7c963af0d6e71", null ],
    [ "xWNetSetPnCode", "a00319.html#ga92aa3c0e04f2e40873da298fd801a478", null ],
    [ "xWNetSingleByteDeviceId", "a00319.html#gade3013c9590ed8e9fd23268f35aaceb0", null ],
    [ "xWNetStatus", "a00319.html#ga4bf9a5e172275f0e93562eec35c446fe", null ]
];