var a00247 =
[
    [ "ucAvrXReadEEProm", "a00247.html#gaae01cf5e73b43462f16c2395c1939fc9", null ],
    [ "usAvrXReadEEPromWord", "a00247.html#ga9b6749e459f5bab3c2072284f7dd973d", null ],
    [ "vAvrXWriteEEProm", "a00247.html#ga536a619c78dc17cf2bcc49a7677f4a5e", null ]
];