var a00285 =
[
    [ "iLcdBacklightSet", "a00285.html#ga949bf74bd36ba357179420b1b81ab90e", null ],
    [ "vLcdCtrlBacklightInit", "a00285.html#ga2fed0e76ce7a1da6dc30b3c4ba7437d6", null ]
];