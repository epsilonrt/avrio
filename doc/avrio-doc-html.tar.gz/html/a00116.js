var a00116 =
[
    [ "ch_mask", "a00116.html#a038b1525d7de85c9479b07db5a4563ba", null ],
    [ "data", "a00116.html#ac5861f74a8e3f0df3a1c5235f24bce63", null ],
    [ "hdr", "a00116.html#a6a0c86bc7db64f5f01bdfad8fe119447", null ],
    [ "num_samples", "a00116.html#a99d0a92966ba8a4a1721fb843bac0279", null ],
    [ "opt", "a00116.html#a6274c47a4b991a399ac918ef753b8876", null ],
    [ "rssi", "a00116.html#a3a37c76dcd3871c410b857c078bcec71", null ],
    [ "src", "a00116.html#af71b300f13dda9934a27cc2d3301b29b", null ],
    [ "type", "a00116.html#a0585cb18730470e66056dc164b1c4a23", null ]
];