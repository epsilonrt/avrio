var a00301 =
[
    [ "AVRIO_KERNEL_ERROR", "a00301.html#ga6e884baf49f3c652c41139553acdc8af", null ],
    [ "xTaskFunction", "a00301.html#ga1b868e30237dc225972351bece07b071", null ],
    [ "xTaskHandle", "a00301.html#gada7d5663923d612aa2755d64970efbc5", null ],
    [ "vTaskRewind", "a00301.html#ga3925a77647b7f90c70bc15ee73e5d937", null ],
    [ "vTaskSetInterval", "a00301.html#gaabf5099a3e388a817afe1aa3ba9cb244", null ],
    [ "vTaskStart", "a00301.html#gac030af06b25f27058a508ed525eee70e", null ],
    [ "vTaskStop", "a00301.html#ga81c8fee5e38cff8677c0321c079f700f", null ],
    [ "xTaskConvertMs", "a00301.html#ga644315929bc0525c5cad17294a3c76d4", null ],
    [ "xTaskCreate", "a00301.html#gaca70f6fef12558668cef68efc689ef21", null ],
    [ "xTaskIsStarted", "a00301.html#ga2d0d90cf871894f09c3e5b2ed04c75b5", null ],
    [ "xTaskSystemTime", "a00301.html#ga5bf33ae162498a4161c584a6992c553b", null ]
];