var a00258 =
[
    [ "xCompass3dCalibration", "a00065.html", [
      [ "iMax", "a00065.html#ad4cc00b17ed82c67ac9a176fe813d359", null ],
      [ "iMin", "a00065.html#a12fd269cd657ee1b5bca340eb394e747", null ]
    ] ],
    [ "COMPASS3D_NOT_CALIBRATED", "a00258.html#gae5173f0d12e582ca3116317f5eee81ac", null ],
    [ "fCompass3dHeadingRadian", "a00258.html#ga53db047b8b7c43bb03fdfb13f5f43adc", null ],
    [ "iCompass3dCalibrate", "a00258.html#ga5b32ba7cdd4d6fba9213cce8f761fcb0", null ],
    [ "iCompass3dHeading", "a00258.html#ga52a2d7036bcfb867e10cb703027ef6af", null ],
    [ "iCompass3dHeadingFrom", "a00258.html#ga9d26054fdedda9512b232c612e194c61", null ],
    [ "iCompass3dInit", "a00258.html#ga1a1d72b01947c6b6a81a494baa367777", null ],
    [ "iCompass3dRead", "a00258.html#ga9ad3ae756d6535e1b2bb390e2ace81b6", null ],
    [ "iCompass3dReadRaw", "a00258.html#gab9da9463bf650b5860b2719f2a07ab1b", null ],
    [ "vCompass3dCalibration", "a00258.html#gaff25cb894ae8e034c4eb0965a4845942", null ],
    [ "vCompass3dClearCalibration", "a00258.html#ga0fa04001c785460cb39c3e04d39d1660", null ],
    [ "vCompass3dSetCalibration", "a00258.html#gad54c80b16795754ed9e938cd18cc8352", null ]
];