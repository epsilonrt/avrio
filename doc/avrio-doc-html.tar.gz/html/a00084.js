var a00084 =
[
    [ "ucBlue", "a00084.html#a545329d4d2a223b1e21d74062cc007b4", null ],
    [ "ucGreen", "a00084.html#a6ebb8b4ed3b9b4142c55cda9bdf85570", null ],
    [ "ucHue", "a00084.html#aa2715570c1a29f57fc2bae2d279c980f", null ],
    [ "ucRed", "a00084.html#a0a38eebb8f41f2b489e679dcadaf87ad", null ],
    [ "ulRgb", "a00084.html#a494d348ad86608c4502d33f1c9448f81", null ]
];