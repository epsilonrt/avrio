var NAVTREE =
[
  [ "AvrIO", "index.html", [
    [ "Présentation", "index.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Structures de données", null, [
      [ "Structures de données", "annotated.html", "annotated" ],
      [ "Index des structures de données", "classes.html", null ],
      [ "Champs de donnée", "functions.html", [
        [ "Tout", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Exemples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"a00002.html",
"a00104.html",
"a00240.html#ga2b5f577579c3fb3b304f57b9b4881463",
"a00262.html#gga05f65aed7e1178a485de99235f8d3f8aacadab144e194a97779c1b3cf48db3518",
"a00283.html#gade0aba41c3b3e8efbd6ed49481bb4f6a",
"a00304.html#ggadae8b1d38eeb34e3cdf21f19d957f772a218985289d9d2431841321a1f06d89b8",
"a00316.html"
];

var SYNCONMSG = 'cliquez pour désactiver la synchronisation du panel';
var SYNCOFFMSG = 'cliquez pour activer la synchronisation du panel';