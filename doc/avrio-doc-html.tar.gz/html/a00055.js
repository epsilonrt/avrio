var a00055 =
[
    [ "dRawMax", "a00055.html#a13ed04b9c4f33a2df21606e5461d4f4f", null ],
    [ "dRawMin", "a00055.html#ac34937d170995e7a4a924c5a717498f3", null ],
    [ "dValueMax", "a00055.html#a1b060ad37bb25cab59ca93da21b146ec", null ],
    [ "dValueMin", "a00055.html#a669295b7e3757633ca4c3eb42787f7d6", null ]
];