var a00104 =
[
    [ "ucFlag", "a00104.html#aae046d837110de69167f1a2093546085", null ],
    [ "ucNoiseThreshold", "a00104.html#aa1f3eedab2484eb1ef25440acdb19f14", null ],
    [ "xConfig", "a00104.html#a20866512ddd6097dceb554659e81b930", null ],
    [ "xMsg", "a00104.html#ae394ba9b76061731ff411dd878689956", null ],
    [ "xService", "a00104.html#ac37c46d90b6f6e9efeee5d08c1919c06", null ]
];