var a00290 =
[
    [ "vMutexLockBit", "a00290.html#ga09e8b4b05b727094a5939c96f7db10f3", null ],
    [ "vMutexUnlockBit", "a00290.html#gaefc036c322891884d9eaca9f52074827", null ],
    [ "vMutexUntilBitUnlocked", "a00290.html#gaa939ef1eaa0f1443f142ba23df68440e", null ],
    [ "xMutexBitLocked", "a00290.html#gaaa3a4c8c008448bae0ba7eb07a9ca907", null ],
    [ "xMutexTryLockBit", "a00290.html#gadd96cf0aeb61fe6d274d6d45789eea33", null ]
];