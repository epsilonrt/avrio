var a00228 =
[
    [ "Codes d'erreur système", "a00258.html", "a00258" ],
    [ "Définitions pour le timer 16 bits", "a00259.html", "a00259" ],
    [ "_BV", "a00228.html#gaa77651eaceb9b65b49d961206d14a1e3", null ],
    [ "ABS", "a00228.html#ga144863298ff0e1bf0676cc2fb8620563", null ],
    [ "cbi", "a00228.html#gade7326b593651633fd358814e98a9585", null ],
    [ "DEG_TO_RAD", "a00228.html#gad8a6d2f1b198479250deda239a58a349", null ],
    [ "inp", "a00228.html#ga4c90ab16d0671323dd5eeb5eefaab0f0", null ],
    [ "LSB", "a00228.html#ga34a3aa6cbadec6a80ab1eae8efd0083d", null ],
    [ "MAX", "a00228.html#gafa99ec4acc4ecb2dc3c2d05da15d0e3f", null ],
    [ "MIN", "a00228.html#ga3acffbd305ee72dcd4593c0d8af64a4f", null ],
    [ "MSB16", "a00228.html#ga5ccb7bd2ad293f591401580adc654541", null ],
    [ "NOP", "a00228.html#gad99fda6bb7696991797c925f968234b9", null ],
    [ "outp", "a00228.html#ga51b018fc07592395c8fc320426dee402", null ],
    [ "RAD_TO_DEG", "a00228.html#ga8563d8402f648b961fc9a0726169c0b7", null ],
    [ "sbi", "a00228.html#ga8ddc91bce468d0267159e2520bf64371", null ],
    [ "STRUCT_FIELD_OFFSET", "a00228.html#ga60eac7970c2762d213a253ee61a1461d", null ],
    [ "tbi", "a00228.html#ga65de8de0508148bd7e073c3877b40d99", null ]
];