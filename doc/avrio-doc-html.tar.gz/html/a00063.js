var a00063 =
[
    [ "xDlc", "a00063.html#a4c91a3dc1fb0dede3e61e0f95cd3bcbf", null ],
    [ "xR0", "a00063.html#a7e274423c8ea98a6790e4dfc23926038", null ],
    [ "xR1", "a00063.html#af6e10b37885002d3733168d15702451e", null ],
    [ "xUnused", "a00063.html#ac2111a2cba9eab9c1a9118ca6d37bed1", null ],
    [ "xValue", "a00063.html#aa1ed9fb6045a1dac6d46354bb014d5bc", null ]
];