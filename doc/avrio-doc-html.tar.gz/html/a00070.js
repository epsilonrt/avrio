var a00070 =
[
    [ "dPressMax", "a00070.html#a68507f51f0a34708c8424ddc6374c0b7", null ],
    [ "dPressMin", "a00070.html#a11257b6d93287cc2e91d741f6a6c32e9", null ],
    [ "eBus", "a00070.html#a70208029056d83203aa8d3999ca18940", null ],
    [ "ucI2cAddr", "a00070.html#abe928eb507fe3f9363777c905d2cfbc8", null ],
    [ "vInit", "a00070.html#a6dc339920af3eec31271997243d56fc8", null ],
    [ "vSelect", "a00070.html#ac2a53d33bd0ab0131e45c47fcfef92fa", null ]
];