var a00267 =
[
    [ "xHih6130Data", "a00067.html", [
      [ "iHum", "a00067.html#a42531068028351eba706204b900292bf", null ],
      [ "iTemp", "a00067.html#a90f55c4ba8e476d0535564c769933b0e", null ]
    ] ],
    [ "HIH6130_ADDR", "a00267.html#gac282d7783b6b11f7894686d9f3bb8b13", null ],
    [ "xHih6130Data", "a00267.html#gae39725aca0f5faca62e0bfdf44a6cffb", null ],
    [ "eHih6130Error", "a00267.html#ga111ea31895041ec3c94a26eb4aa01d5a", [
      [ "HIH6130_BUSY", "a00267.html#gga111ea31895041ec3c94a26eb4aa01d5aaafd1a03b2eb40260036db8bbf7729b66", null ],
      [ "HIH6130_SUCCESS", "a00267.html#gga111ea31895041ec3c94a26eb4aa01d5aacd9cbde364c747eae087ab6aeaf1a8ef", null ],
      [ "HIH6130_TWIERR", "a00267.html#gga111ea31895041ec3c94a26eb4aa01d5aab7471c424e05a7b9b4f08430b7ba6360", null ],
      [ "HIH6130_NODATA", "a00267.html#gga111ea31895041ec3c94a26eb4aa01d5aa485fe42f7551f0a2bc6449f05bdbde3e", null ]
    ] ],
    [ "eHih6130Init", "a00267.html#gaebd5e9ac47463bafa9eac4ff71350b08", null ],
    [ "eHih6130Read", "a00267.html#gac91ef06bb79f57a946214a9721f49a2f", null ],
    [ "eHih6130Start", "a00267.html#ga259d390dc578d6e2862313e9b1c055ad", null ],
    [ "eHih613LastTwiError", "a00267.html#ga808485e49f80457b72bda2d9bfcad080", null ]
];