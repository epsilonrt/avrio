var a00054 =
[
    [ "eType", "a00054.html#a0407051cc2380c137bd76197fb3d2801", null ],
    [ "pSetting", "a00054.html#a586c0be18a2bdb017ae3dd4e4a5c2c7d", null ],
    [ "ucAdcChan", "a00054.html#a3436e5fa442b8ff063d7b6e8b53b421d", null ],
    [ "ucAdcScale", "a00054.html#afecaf8005afc7ee1baf0824609fd188e", null ],
    [ "ucMeanTerms", "a00054.html#a37bfa805f93f881b218162465ecba9b0", null ]
];