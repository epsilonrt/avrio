var a00268 =
[
    [ "GYRO3D_NOT_CALIBRATED", "a00268.html#gacbbb508ba26e0ee8a47cd4002ce2b668", null ],
    [ "iGyro3dAttitude", "a00268.html#ga358dba1506a2a14a67c3a3368fc1f738", null ],
    [ "iGyro3dCalibrate", "a00268.html#ga79220ee79c62d2aa867024f5984538d6", null ],
    [ "iGyro3dInit", "a00268.html#ga88bbe1f74b2b2fc07ed3682690de755c", null ],
    [ "iGyro3dRead", "a00268.html#ga4e979c51bd66a826ea06f73d470b5ae3", null ],
    [ "iGyro3dReadRaw", "a00268.html#ga64711270a9bf9439da780676c53eefcc", null ],
    [ "vGyro3dAttidudeClear", "a00268.html#ga166720613d7b4e0666b26ff1f4d351ac", null ],
    [ "vGyro3dSaveZero", "a00268.html#ga22a6d6626a1462a0bd456fb8940839ae", null ],
    [ "vGyro3dSetZero", "a00268.html#ga76ac3e31450105a9a46cda090f5cb665", null ],
    [ "vGyro3dZero", "a00268.html#ga1353432105c15d6f061f6fb10a5e2402", null ]
];