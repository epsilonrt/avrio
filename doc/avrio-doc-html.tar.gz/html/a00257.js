var a00257 =
[
    [ "xCanArbField", "a00062.html", [
      [ "xId", "a00062.html#a502a5f8778edf85c23acd24f58a6f1d9", null ],
      [ "xIde", "a00062.html#a17d6ea5acad980295a5ce616ed2d039a", null ],
      [ "xRtr", "a00062.html#aaf9b52a805789b8e91a54dc28507956b", null ],
      [ "xUnused", "a00062.html#a4e49fce9d05c84082b26f82ca438620a", null ],
      [ "xValue", "a00062.html#afbcb9d76826c255392eff20739b97035", null ]
    ] ],
    [ "xCanCtrlField", "a00063.html", [
      [ "xDlc", "a00063.html#a4c91a3dc1fb0dede3e61e0f95cd3bcbf", null ],
      [ "xR0", "a00063.html#a7e274423c8ea98a6790e4dfc23926038", null ],
      [ "xR1", "a00063.html#af6e10b37885002d3733168d15702451e", null ],
      [ "xUnused", "a00063.html#ac2111a2cba9eab9c1a9118ca6d37bed1", null ],
      [ "xValue", "a00063.html#aa1ed9fb6045a1dac6d46354bb014d5bc", null ]
    ] ],
    [ "xCanFrame", "a00064.html", [
      [ "ucData", "a00064.html#a05201128901debceeaf273912f54ae51", null ],
      [ "xArb", "a00064.html#acbfbafe488484cc6e931ad978ebf9fac", null ],
      [ "xCtrl", "a00064.html#afcfb8e9661cc1e9eb9913fd13716f44d", null ]
    ] ],
    [ "eCanError", "a00257.html#gaf501111b81b4273e955a6bc7008f2434", [
      [ "CAN_SUCCESS", "a00257.html#ggaf501111b81b4273e955a6bc7008f2434a8896d67b488b4fcf29c391190214bbe9", null ],
      [ "CAN_TXBUF_FULL", "a00257.html#ggaf501111b81b4273e955a6bc7008f2434aef9812d68707121b769269b7a9aa0719", null ],
      [ "CAN_RXBUF_EMPTY", "a00257.html#ggaf501111b81b4273e955a6bc7008f2434ad3ca1e1d1264d509d2d5485572b57413", null ],
      [ "CAN_ILLEGAL_MOB", "a00257.html#ggaf501111b81b4273e955a6bc7008f2434a657b18b236d9470d9ad2635a767af35f", null ],
      [ "CAN_INVALID_SPEED", "a00257.html#ggaf501111b81b4273e955a6bc7008f2434a964a9faa7d8c75db0531c0167e11ccd2", null ],
      [ "CAN_PASSIVE", "a00257.html#ggaf501111b81b4273e955a6bc7008f2434a9a5d1802995d398213899bbbfcd4283e", null ],
      [ "CAN_BUS_OFF", "a00257.html#ggaf501111b81b4273e955a6bc7008f2434ac8cadafe6fe9deff8a983e28190042b1", null ],
      [ "CAN_TIMEOUT", "a00257.html#ggaf501111b81b4273e955a6bc7008f2434afeff6df2ef6aaca2b8380217e7505e7d", null ]
    ] ],
    [ "eCanSpecification", "a00257.html#ga67fa8deebd20a8d882d824b0b1fe9776", [
      [ "CAN_2A", "a00257.html#gga67fa8deebd20a8d882d824b0b1fe9776a1274100e89b60b4ee714761f0713ff67", null ],
      [ "CAN_2B", "a00257.html#gga67fa8deebd20a8d882d824b0b1fe9776a79d8267ca0083d6d73d8202c4f7348e9", null ]
    ] ],
    [ "eCanSpeed", "a00257.html#ga70ef5056f11d097dec415c95bb528467", [
      [ "CAN_SPEED_10K", "a00257.html#gga70ef5056f11d097dec415c95bb528467a91b253ec5a57d4448c5eed730fee7140", null ],
      [ "CAN_SPEED_20K", "a00257.html#gga70ef5056f11d097dec415c95bb528467a3c6c4e1d689e74b077905024ea382af1", null ],
      [ "CAN_SPEED_50K", "a00257.html#gga70ef5056f11d097dec415c95bb528467a6b76854b92d2f2416c68719ccc705c83", null ],
      [ "CAN_SPEED_100K", "a00257.html#gga70ef5056f11d097dec415c95bb528467a361cc538e29d674750b05940cd227de8", null ],
      [ "CAN_SPEED_125K", "a00257.html#gga70ef5056f11d097dec415c95bb528467a471f0266406d494957d008752abc84f8", null ],
      [ "CAN_SPEED_250K", "a00257.html#gga70ef5056f11d097dec415c95bb528467a0c54d42bb90bbd1b5b73a5e83a535df1", null ],
      [ "CAN_SPEED_500K", "a00257.html#gga70ef5056f11d097dec415c95bb528467aeb8ca14bbfbdc89bd942c3f721aaf293", null ],
      [ "CAN_SPEED_800K", "a00257.html#gga70ef5056f11d097dec415c95bb528467a2fa72888f56aad3b9e759d8d9fcf1770", null ],
      [ "CAN_SPEED_1M", "a00257.html#gga70ef5056f11d097dec415c95bb528467a60d47e2496fa736b81cb37ede04b87de", null ],
      [ "CAN_SPEED_CUSTOM", "a00257.html#gga70ef5056f11d097dec415c95bb528467a064b3e8e88aba4ba6d52eaa8067edf03", null ]
    ] ],
    [ "eCanInit", "a00257.html#ga583f2f1478d56bbfafed7cf695f76fbf", null ],
    [ "eCanReceiveFrame", "a00257.html#gab7056b77719d8843d4c63760b865dc7d", null ],
    [ "eCanSendFrame", "a00257.html#ga719a6b5d44853880b1a3957c0f4f2675", null ],
    [ "eCanSetSpeed", "a00257.html#ga954dbfff5160e28bedce5c5d7498a16b", null ],
    [ "eCanTryReceiveFrame", "a00257.html#ga1a1b3e925e466810f11a460e5b029cd2", null ],
    [ "eCanTrySendFrame", "a00257.html#gaa4a78f724fcdd3b190a14353936ec262", null ],
    [ "ucCanRxAvail", "a00257.html#ga020829ad89d456bf26346ed046ae97cb", null ],
    [ "vCanSetFilter", "a00257.html#gaa90fcc9cb7dd445d37da70f89b08992c", null ],
    [ "vCanSetRxTimeout", "a00257.html#gaa9270b52972dd412282d364ecaf13975", null ],
    [ "xCanTxFree", "a00257.html#ga15d10768baa667aa2b13ae76cfdc3bdc", null ]
];