var a00264 =
[
    [ "xEncoderCounter", "a00264.html#ga846c89de9514802b59aaa9fed3eba9dd", null ],
    [ "eEncoderDir", "a00264.html#ga7c48f9473d808e4e6c4a38737d93a50e", [
      [ "ENCODER_STOP", "a00264.html#gga7c48f9473d808e4e6c4a38737d93a50eaa16d1a09a44bc071b0b873f2fc6b6307", null ],
      [ "ENCODER_CW", "a00264.html#gga7c48f9473d808e4e6c4a38737d93a50ea0624c7a06103c446cffa37b0a6220dd8", null ],
      [ "ENCODER_CCW", "a00264.html#gga7c48f9473d808e4e6c4a38737d93a50ea688495fe56b654fc45fcbd8fbab07740", null ]
    ] ],
    [ "eEncoderDirection", "a00264.html#gacd4183a0af763fd496d4643e1f0e9802", null ],
    [ "vEncoderEnable", "a00264.html#gad57d0e4940bb496426f2aff9c6e51db3", null ],
    [ "vEncoderInit", "a00264.html#ga450e1af0aa64f57fb10185ae075c5fc1", null ],
    [ "vEncoderReset", "a00264.html#ga85a66118fa12f392fdd90b608d197e54", null ],
    [ "xEncoderCount", "a00264.html#ga637503cd832b8ec3bf30d10550a0cc2b", null ],
    [ "xEncoderSpeed", "a00264.html#gadf34ba9464a3a8d2b1ae635f8b182745", null ]
];