var a00061 =
[
    [ "pPort", "a00061.html#a799a76840c51ea943ef9c9e29c9e6a91", null ],
    [ "ucOff", "a00061.html#a6f9d003de179eefa2a42ea7f637ad883", null ],
    [ "ucOn", "a00061.html#a4238bd0f45f312d8aa1b1c0f7197a358", null ]
];