var a00067 =
[
    [ "iHum", "a00067.html#a42531068028351eba706204b900292bf", null ],
    [ "iTemp", "a00067.html#a90f55c4ba8e476d0535564c769933b0e", null ]
];