var a00264 =
[
    [ "DAYS", "a00264.html#ga5997000e8b111a79311c9b2eeac8d3dc", null ],
    [ "delay_ms", "a00264.html#ga200c565cebdcd3f6bb16d6a34044176c", null ],
    [ "delay_us", "a00264.html#ga2fbc056f943fbdb1bdbab96544ce1d14", null ],
    [ "DHMS", "a00264.html#ga54b5279cdc8c5635d16a70e3d1b7e817", null ],
    [ "HMS", "a00264.html#gada0c77f3760d3f5f24b97859d0cd1a62", null ],
    [ "HOURS", "a00264.html#gadddd21815fe708193316433d6e6fc5ae", null ],
    [ "MINUTES", "a00264.html#ga99bc9b3a68b7127d53044b2654fa88bb", null ],
    [ "SECONDS", "a00264.html#ga184d23642f399b7234f023a37b8b5819", null ],
    [ "WDHMS", "a00264.html#ga1c7f7773c9f5d46960d50e8c197439c5", null ],
    [ "WEEKS", "a00264.html#gaf7742a0f6ff7ee80c4c4d339eaa7aace", null ],
    [ "vDelayWaitMs", "a00264.html#gac2b4ccd7152fe4370622bd8cff080fda", null ],
    [ "xDelayMsToTicks", "a00264.html#gab9fcfefed4f8b1a0f9cc2132308831b3", null ]
];