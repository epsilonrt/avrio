var a00310 =
[
    [ "Mode maître", "a00311.html", null ],
    [ "Mode esclave", "a00312.html", null ]
];