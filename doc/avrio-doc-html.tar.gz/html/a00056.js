var a00056 =
[
    [ "dCoeff", "a00056.html#a2589c3397d4e20cd0b8675b573ee32ac", null ],
    [ "dRawToValue", "a00056.html#a4376bcc1231980c947aa1c25f5c79d34", null ]
];