var a00060 =
[
    [ "call", "a00060.html#a94ff5175029c0b2249649c4dae640717", null ],
    [ "ssid", "a00060.html#a50e0032f62051e3f3d2f649d2d81b8e6", null ]
];