var a00252 =
[
    [ "xBisRelay", "a00061.html", [
      [ "pPort", "a00061.html#a799a76840c51ea943ef9c9e29c9e6a91", null ],
      [ "ucOff", "a00061.html#a6f9d003de179eefa2a42ea7f637ad883", null ],
      [ "ucOn", "a00061.html#a4238bd0f45f312d8aa1b1c0f7197a358", null ]
    ] ],
    [ "xBisRelay", "a00252.html#gaf02f7e918f9b53896d789560cd00fb85", null ],
    [ "ucBisRelayGetAll", "a00252.html#gabc143525d3e410f218fb68f10e7f454b", null ],
    [ "vBisRelayClear", "a00252.html#gabdd1a9a47e32c27b2133d5b4ec55416b", null ],
    [ "vBisRelayInit", "a00252.html#gae183dd1c185270048481ec1a2bcf4f7b", null ],
    [ "vBisRelaySet", "a00252.html#ga9bc3424600a2c0e0796c58568245ef1f", null ],
    [ "vBisRelaySetAll", "a00252.html#gaf9038f33e21a9e0511da1df762ff6cb7", null ],
    [ "vBisRelayToggle", "a00252.html#ga343227d027675f82b663872703e1f5c7", null ]
];