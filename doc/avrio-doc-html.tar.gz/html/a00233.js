var a00233 =
[
    [ "ACCELERO3D_NOT_CALIBRATED", "a00233.html#ga0cdcf8d93a828091cdd338d0ae17f0fd", null ],
    [ "iAccelero3dCalibrate", "a00233.html#gadbbbff18ef6de18160eaa82af9a43ae9", null ],
    [ "iAccelero3dInit", "a00233.html#ga0721b350f3633af57bd20e53d4193edc", null ],
    [ "iAccelero3dRead", "a00233.html#gafc6a079745bf6e2a15e837e62a25a3cd", null ],
    [ "iAccelero3dReadRaw", "a00233.html#gaada2a78be44fd93742ef31d7a3b9a5ea", null ],
    [ "vAccelero3dAttitude", "a00233.html#ga02df1ee5c5694a69e5acf3ef818dfde8", null ],
    [ "vAccelero3dSetZero", "a00233.html#ga7353fe6cbc84be1fb3eee9ccc7ce55a3", null ],
    [ "vAccelero3dZero", "a00233.html#ga4928bd6fc0780af8fe1b2d84b5e37bf9", null ]
];