var a00064 =
[
    [ "ucData", "a00064.html#a05201128901debceeaf273912f54ae51", null ],
    [ "xArb", "a00064.html#acbfbafe488484cc6e931ad978ebf9fac", null ],
    [ "xCtrl", "a00064.html#afcfb8e9661cc1e9eb9913fd13716f44d", null ]
];