var a00059 =
[
    [ "ctrl", "a00059.html#ac390866554fab560783b5d5295e26814", null ],
    [ "dst", "a00059.html#aebaf71207191966428926e3499972700", null ],
    [ "info", "a00059.html#a143cdd82eb501603885837ee57ba0ed8", null ],
    [ "len", "a00059.html#ab0aebef9689ddef22008937728c28017", null ],
    [ "pid", "a00059.html#ac1eb9aa106d0bcc9d3c1fe6fde148470", null ],
    [ "src", "a00059.html#acab1b118e8dfd39c065e93d363af4f65", null ]
];