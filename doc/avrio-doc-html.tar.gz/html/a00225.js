var a00225 =
[
    [ "Réseau WirelessUSB", "a00229.html", "a00229" ],
    [ "Bus I2C", "a00230.html", "a00230" ],
    [ "Liaisons radio", "a00232.html", "a00232" ],
    [ "Bus CAN", "a00254.html", "a00254" ],
    [ "Liaison HDLC", "a00266.html", "a00266" ],
    [ "Bus SPI", "a00297.html", "a00297" ],
    [ "XBee", "a00319.html", "a00319" ]
];