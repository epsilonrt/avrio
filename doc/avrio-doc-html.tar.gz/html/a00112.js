var a00112 =
[
    [ "command", "a00112.html#aef2031a30a22a1d2630530ca433cc901", null ],
    [ "frame_id", "a00112.html#afaff3798c894c45723d110f8a6910783", null ],
    [ "hdr", "a00112.html#a3923f96f297a2ae3f673ed900f1c74c5", null ],
    [ "param", "a00112.html#a5dcc8f7a45ee6aa11f94e1d80a60b335", null ],
    [ "src16", "a00112.html#a765f38968012a55cb47633f2e6b6d7ba", null ],
    [ "src64", "a00112.html#a49928f92f2fc5318c98c42420fb7d631", null ],
    [ "status", "a00112.html#ad98cecf7f9c18382a4c3104fd0cdeb62", null ],
    [ "type", "a00112.html#a40e57289e5e734834cccf8023e3c69e9", null ]
];