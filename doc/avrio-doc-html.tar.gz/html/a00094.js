var a00094 =
[
    [ "pxData", "a00233.html#ga5b7c9b97ec897f1daca558a3c38c64f1", null ],
    [ "xAddr", "a00233.html#ga969453b8620c2b3cbf743c8146cfc5a7", null ],
    [ "xLen", "a00233.html#ga862e5b94d2d295f11f320e250d83999b", null ]
];