var a00090 =
[
    [ "iHSize", "a00090.html#a6b7f649b2174397848f43eacf6a0f480", null ],
    [ "iVSize", "a00090.html#a81c6d9fdac3e7a47c1a894a6a32ec403", null ]
];