var a00291 =
[
    [ "xPidData", "a00079.html", [
      [ "fKd", "a00079.html#abc6fcfb22bbd42c95f3f68200b707f05", null ],
      [ "fKi", "a00079.html#af41d0209c7546431250fff59f5d0bfde", null ],
      [ "fKp", "a00079.html#a9d00aca419ecd916d57ab849774aa92f", null ],
      [ "iLastProcessValue", "a00079.html#ac57eb77c38346f99c589deb723dea707", null ],
      [ "iSumError", "a00079.html#a3776cbd9dafa49b0135caa3db7327998", null ]
    ] ],
    [ "xPidData", "a00291.html#ga8ad220d590ba748c4a52be1d7e730dcd", null ],
    [ "iPidProcess", "a00291.html#ga50bf62ec74239d3016a3d4ca2f95ff2d", null ],
    [ "vPidInit", "a00291.html#gaa9de7b58fcbe60ad367bff42015dbe2c", null ],
    [ "vPidResetIntegrator", "a00291.html#gabf47ee287e0e675afd38ebe83f813bb4", null ]
];