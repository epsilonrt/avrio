var a00075 =
[
    [ "eFlag", "a00075.html#a6d982b4b21ccd7755d59db3d071eafa5", null ],
    [ "pcName", "a00075.html#ae3e8aab75f5bffe168c570d0e3e87e57", null ],
    [ "pvFunc", "a00075.html#ad7c5eb492cd66f9948299346fec0135b", null ],
    [ "pvItem", "a00075.html#a72a9cc285cb8adce23cea15bd2d858f8", null ],
    [ "pxMenu", "a00075.html#a0b5bc724edf97f2902ff0e4c2619333e", null ],
    [ "xAction", "a00075.html#a0d10a7659a40700fa13d9c99248ad662", null ],
    [ "xRaw", "a00075.html#aee996f576e999dbe54c449d616001a28", null ],
    [ "xSubMenu", "a00075.html#a6505b40bcf6baace6daa041a80d8e1a0", null ]
];