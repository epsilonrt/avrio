var a00068 =
[
    [ "iHum", "a00068.html#a42531068028351eba706204b900292bf", null ],
    [ "iTemp", "a00068.html#a90f55c4ba8e476d0535564c769933b0e", null ]
];