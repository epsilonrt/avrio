var a00100 =
[
    [ "ucChannel", "a00100.html#a576724af66ca23ebab68263cc24a83f4", null ],
    [ "ucChecksumSeed", "a00100.html#ae1f82a6703eac4c24bba8f182c77a200", null ],
    [ "ucCrcSeed", "a00100.html#acaf22bd968685ffdf258f4c8159e0ae8", null ],
    [ "ucPnCode", "a00100.html#a86a2994f17ff8e05cb96549d39c75804", null ],
    [ "ucStatus", "a00100.html#a86dc1fc7a42754442184117e8ed124cc", null ]
];