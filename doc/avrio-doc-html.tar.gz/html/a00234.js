var a00234 =
[
    [ "ADC_MEASUREMENT", "a00234.html#ga8d5b3cdd5e94817a54a94198cb670d31", null ],
    [ "ADC_VALUE", "a00234.html#gaaa5541b80d0b9c9d90de8e5fd4d32ed1", null ],
    [ "eAdcRef", "a00234.html#ga69f608d59a555a7c535d5d735934b5d4", [
      [ "eAdcExternal", "a00234.html#gga69f608d59a555a7c535d5d735934b5d4abe5f8ebd0f2cc8a83f60af824a1cba0a", null ],
      [ "eAdcVcc", "a00234.html#gga69f608d59a555a7c535d5d735934b5d4a82acc68be51661abafab1ba1472faf4b", null ],
      [ "eAdcInternal", "a00234.html#gga69f608d59a555a7c535d5d735934b5d4a53b88120e44491f2b1d3781f50fcb145", null ]
    ] ],
    [ "eAdcGetRef", "a00234.html#gaa92e9a12b0127294a3affa58bf5c3c06", null ],
    [ "ucAdcGetScale", "a00234.html#ga421327e4ef80227fa5abea2c30d0d341", null ],
    [ "usAdcRead", "a00234.html#ga06c873bec019184b3ca40004145bbbca", null ],
    [ "usAdcReadAverage", "a00234.html#gaf2791a2967484c22581ae0866c4ec300", null ],
    [ "vAdcClearAutoscale", "a00234.html#ga970a0696ac66444f8677c81a3038638c", null ],
    [ "vAdcDisable", "a00234.html#gae87c136f2f7d1a1bdebc50bcb5f00724", null ],
    [ "vAdcEnable", "a00234.html#ga7b63d353cf77f8ce275b48ed133135db", null ],
    [ "vAdcInit", "a00234.html#gafd363a68cef637598cf2717923f633b8", null ],
    [ "vAdcSetChannel", "a00234.html#ga4cfaa08fb2ebfc9d8c43b51a4c179b54", null ],
    [ "vAdcSetRef", "a00234.html#gab7efb6519841c9f14523ff0c6668f773", null ],
    [ "vAdcSetScale", "a00234.html#ga700eec44e57e5e91ccc71ba15266b961", null ]
];