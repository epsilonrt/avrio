var a00320 =
[
    [ "pxWNetTxPacket", "a00320.html#gaac71dee975ee2ec6aa87d2d34078ca94", null ],
    [ "vWNetTxPktAddByte", "a00320.html#ga23bab9d5f060def6927bb5ac2e06e150", null ],
    [ "vWNetTxPktAddBytes", "a00320.html#ga86a01ccc516f1b71ca21fea6f2c2b315", null ],
    [ "vWNetTxPktAddBytes_P", "a00320.html#ga3e6eacbd4407adb9c8d9656bd5107c93", null ],
    [ "vWNetTxPktAddDeviceId", "a00320.html#ga7c66547263ea6843fe872e80bc7c711a", null ],
    [ "vWNetTxPktAddStr", "a00320.html#ga2b1a8202569a54add113ae4bd703fc1d", null ],
    [ "vWNetTxPktAddStr_P", "a00320.html#gadd46058238c3cfe05257fe2cae0e150a", null ],
    [ "vWNetTxPktAddTrailer", "a00320.html#ga835df4c53055adad2d4471d63e420d22", null ],
    [ "vWNetTxPktAddWord", "a00320.html#gaae89316bc1cf9854d6ec1d719584eae7", null ],
    [ "vWNetTxPktNew", "a00320.html#ga3de1c84f21e09fa5fc5d42b217dd0801", null ],
    [ "vWNetTxPktSend", "a00320.html#gab28da67078861db0c75e6e88f0188c16", null ],
    [ "vWNetTxPktSetFlag", "a00320.html#gaaf97061fee9e48a516e7ba311508b1d3", null ],
    [ "vWNetTxPktSetHeader", "a00320.html#ga5adaceaa045bc6812d8147a64599b444", null ],
    [ "vWNetTxPktSetType", "a00320.html#gac982566858ab2e9300734daa7c0e304f", null ],
    [ "vWNetTxPktToggleFlag", "a00320.html#ga027079bda4f78b1e10c2864aba8fc2b8", null ]
];