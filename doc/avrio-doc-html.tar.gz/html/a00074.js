var a00074 =
[
    [ "eFlag", "a00074.html#a6da08d23a5eb1144550e231047a75d62", null ],
    [ "iSize", "a00074.html#a012a0739c22fc369a0a1991a8b9ccee2", null ],
    [ "pcName", "a00074.html#ae6683628a012cc3583084fe9469a5e81", null ],
    [ "pxItem", "a00074.html#a7a82b0bc64d759edb5b63803036b7006", null ],
    [ "pxUp", "a00074.html#ac5a81aa28f2996db7a5d72ba84b0e409", null ]
];