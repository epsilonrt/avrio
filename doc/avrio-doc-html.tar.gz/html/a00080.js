var a00080 =
[
    [ "fKd", "a00080.html#abc6fcfb22bbd42c95f3f68200b707f05", null ],
    [ "fKi", "a00080.html#af41d0209c7546431250fff59f5d0bfde", null ],
    [ "fKp", "a00080.html#a9d00aca419ecd916d57ab849774aa92f", null ],
    [ "iLastProcessValue", "a00080.html#ac57eb77c38346f99c589deb723dea707", null ],
    [ "iSumError", "a00080.html#a3776cbd9dafa49b0135caa3db7327998", null ]
];