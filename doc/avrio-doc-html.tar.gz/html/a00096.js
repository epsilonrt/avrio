var a00096 =
[
    [ "Regs", "a00229.html#gaaa56221d93094b59eb1be0a496108463", null ],
    [ "Size", "a00229.html#gae52d47207df40268311381159adaa65c", null ]
];