var a00262 =
[
    [ "DS1621_BASE", "a00262.html#gacd81ca0639d82ef56a4af378edb85675", null ],
    [ "eDs1621Cmd", "a00262.html#ga05f65aed7e1178a485de99235f8d3f8a", [
      [ "DONE", "a00262.html#gga05f65aed7e1178a485de99235f8d3f8aa9c954bcf443428c80b0f107b3bc48749", null ],
      [ "THF", "a00262.html#gga05f65aed7e1178a485de99235f8d3f8aacda63a7d5325cd41e7557704dff9d081", null ],
      [ "TLF", "a00262.html#gga05f65aed7e1178a485de99235f8d3f8aa9f96227b8ba4acd0d86bd0788afd723d", null ],
      [ "NVB", "a00262.html#gga05f65aed7e1178a485de99235f8d3f8aab97650962cf07781b013b93ccdcdae2f", null ],
      [ "POL", "a00262.html#gga05f65aed7e1178a485de99235f8d3f8aacadab144e194a97779c1b3cf48db3518", null ],
      [ "ONESHOT", "a00262.html#gga05f65aed7e1178a485de99235f8d3f8aa2724fa87f252403cd2c93f7437f34fd5", null ],
      [ "TAF", "a00262.html#gga05f65aed7e1178a485de99235f8d3f8aac522c794459fda56f053a51c5b83c27e", null ],
      [ "DS1621_DEFAULT_CONFIG", "a00262.html#gga05f65aed7e1178a485de99235f8d3f8aa3eb1dcae920d2344cb9d761dbd21dcb8", null ]
    ] ],
    [ "eDs1621LastError", "a00262.html#ga6b215f8980377020ca4b47725e248cee", null ],
    [ "iDs1621GetTemp", "a00262.html#gad2c41c7ab664f3bc4696ff97f306aaea", null ],
    [ "iDs1621GetTh", "a00262.html#ga5a00ac89391b4045ee1bc0afe5fcfa6a", null ],
    [ "iDs1621GetTl", "a00262.html#ga8adeec8a1f50ab0f1515da5a7b60120f", null ],
    [ "ucDs1621GetCounter", "a00262.html#gaf2529303640739abb917ff57822a17c0", null ],
    [ "ucDs1621GetSlope", "a00262.html#ga3307cb1d2c6bfef3252a1901ff0eab1d", null ],
    [ "ucDs1621GetStatus", "a00262.html#ga7fb07467d7a69bbb8faad15cc02ef725", null ],
    [ "vDs1621ClrFlags", "a00262.html#gae426fa20a40c5b3403926aa360690408", null ],
    [ "vDs1621Init", "a00262.html#gafaed5762155e698f5cbfd7dcef1d48b6", null ],
    [ "vDs1621SetTh", "a00262.html#gaf0845830e46b28105efa9be4042b2207", null ],
    [ "vDs1621SetTl", "a00262.html#ga6312d154bd96eedb5c41b6e74ba3fbcb", null ],
    [ "vDs1621Start", "a00262.html#gaf4366ddebdd6bbfb123cbfd588385801", null ],
    [ "vDs1621Stop", "a00262.html#gaa1bb0928fea7350d513ce1ddaa17e3f8", null ],
    [ "xDs1621IsDone", "a00262.html#ga6f5c13e9d5f4c9c092fd7a58431e57b2", null ],
    [ "xDs1621MemIsBusy", "a00262.html#ga2f13cc2b54033818887715f2b5602c48", null ]
];