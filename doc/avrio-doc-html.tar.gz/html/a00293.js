var a00293 =
[
    [ "cPhoneMsgGetChar", "a00293.html#ga77b3d7ac3c9b374581b445b5e0a80c42", null ],
    [ "iPhoneSetHookoffDelay", "a00293.html#gacf1af8297be0a69f935023352d61e2fd", null ],
    [ "ucPhoneHookoffDelay", "a00293.html#ga1a0238138d3134b1b89e8932d6b4aaf5", null ],
    [ "ucPhoneMsgLength", "a00293.html#ga3f9f8fc3ce0cb6331fa416a3e4a177b9", null ],
    [ "vPhoneHangup", "a00293.html#ga16f236b60bdafcf2c318308d1a660adc", null ],
    [ "vPhoneHookoff", "a00293.html#gaf2caba16905e6ded5344614f6f8815e3", null ],
    [ "vPhoneInit", "a00293.html#gab67f4161584efe6090e6109594d06e56", null ],
    [ "xPhoneHangupRequest", "a00293.html#ga09516a5a3b79189bfe980b966d2b351e", null ],
    [ "xPhoneOffHook", "a00293.html#gaee3853a21e62dd3ebeb3e38d2b183c39", null ]
];