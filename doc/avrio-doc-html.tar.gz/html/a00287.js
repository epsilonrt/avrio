var a00287 =
[
    [ "Liste des notes", "a00288.html", "a00288" ],
    [ "xNote", "a00079.html", [
      [ "length", "a00079.html#a4262142333169a606fbf2a08d77a75cc", null ],
      [ "pitch", "a00079.html#a580255e9f19354125a4bcd96f5624de4", null ]
    ] ],
    [ "EIGHTH", "a00287.html#ga7b75b0b5f442398526030599aef15216", null ],
    [ "HALF", "a00287.html#ga37c4c48ff47f0838f64b5a1fb3c803b2", null ],
    [ "MELODY_BEEP", "a00287.html#ga2214d39634bcb1d621ed61db3dfed68b", null ],
    [ "MELODY_ERROR", "a00287.html#ga6b43e57968ab21a9ccc12bd8aed2f086", null ],
    [ "MELODY_SYS_MAX", "a00287.html#ga00f615d39ba4bccdad7abf27e8b60ffb", null ],
    [ "MELODY_WARNING", "a00287.html#gafb1f07588af55d9354064616b49ec7f9", null ],
    [ "MELODY_WELCOME", "a00287.html#ga002faa7144817596583a209f1ba39e71", null ],
    [ "QUARTER", "a00287.html#ga641d13af9fb651f951b55064ab61d5bd", null ],
    [ "WHOLE", "a00287.html#ga7c034962522e1f421dd8ca3ffe0ab154", null ],
    [ "ucMelodyDuration", "a00287.html#ga2b5216832355cbf0aa705e6d8bf99834", null ],
    [ "ucMelodyInternote", "a00287.html#gaef70fa266e6d5b136783d84e41dff6a8", null ],
    [ "vMelodyBeep", "a00287.html#ga01d69ddb18a6828db0491030ba7972de", null ],
    [ "vMelodyInit", "a00287.html#gaacf2861724d955829c3b53b13da09548", null ],
    [ "vMelodyPause", "a00287.html#ga620f65d8283b41b2915d097931d10024", null ],
    [ "vMelodyPlay", "a00287.html#ga488c3c14e59d6a24d8a0b021ee450037", null ],
    [ "vMelodyPlayFlash", "a00287.html#gaa24e06609f3fa054327ec3f5ce504c48", null ],
    [ "vMelodyPlaySystem", "a00287.html#gade0aba41c3b3e8efbd6ed49481bb4f6a", null ],
    [ "vMelodySetDuration", "a00287.html#ga0264a72a94262a165cd08e6582cca572", null ],
    [ "vMelodySetInternote", "a00287.html#gaada849a6d5038dae1cea92e18c615406", null ],
    [ "vMelodyStop", "a00287.html#gafddbc7eddf0e7c04170b543fcbac0c29", null ],
    [ "vMelodyTopChangedCB", "a00287.html#ga579ef57281c9eee3f609154bc97214f5", null ],
    [ "xMelodyIsPlay", "a00287.html#ga371dc04c3f451951f5d9be8dbcf8752c", null ]
];