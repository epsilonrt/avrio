var a00102 =
[
    [ "usNextFreeDeviceId", "a00315.html#gacecc52ba3937a0cef0fe6e5e7b202c56", null ],
    [ "usSize", "a00315.html#gaf8cf9ba8e1dcc70801a6399e13450895", null ]
];