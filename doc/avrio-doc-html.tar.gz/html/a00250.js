var a00250 =
[
    [ "eBatCharge", "a00250.html#ga6cec56450dbcf28aab5688fa825219e2", [
      [ "BAT_CHARGE_OFF", "a00250.html#gga6cec56450dbcf28aab5688fa825219e2a2f2f24db98012d5fe1b88987815f5f8c", null ],
      [ "BAT_CHARGE_TRICKLE", "a00250.html#gga6cec56450dbcf28aab5688fa825219e2a5e8fd45222d59f9fd14cbe8ea4c1f75f", null ],
      [ "BAT_CHARGE_TOPOFF", "a00250.html#gga6cec56450dbcf28aab5688fa825219e2aae88ce145c08195220e073e331df2a60", null ],
      [ "BAT_CHARGE_FAST", "a00250.html#gga6cec56450dbcf28aab5688fa825219e2a37155b6e5603fa01729af66345fca633", null ]
    ] ],
    [ "eBatState", "a00250.html#ga784c8453c304308211f862af878e4e38", [
      [ "BAT_STATE_LOW", "a00250.html#gga784c8453c304308211f862af878e4e38a38cb5bee543c35a3d63f3d824b9c23e3", null ],
      [ "BAT_STATE_IDLE", "a00250.html#gga784c8453c304308211f862af878e4e38a49e48558263e08cf46be0bd7c60aa09f", null ],
      [ "BAT_STATE_PUTON", "a00250.html#gga784c8453c304308211f862af878e4e38a6252f6f1e7d3342616e2eb819f32524f", null ],
      [ "BAT_STATE_PRECHARGE", "a00250.html#gga784c8453c304308211f862af878e4e38a6314d2d339edb6d211973bb411c8dc58", null ],
      [ "BAT_STATE_FAST", "a00250.html#gga784c8453c304308211f862af878e4e38a40ecae31c88885587f574b4eade5cf63", null ],
      [ "BAT_STATE_TOPOFF", "a00250.html#gga784c8453c304308211f862af878e4e38abee89a8660f7df6e947baef2e60808e4", null ],
      [ "BAT_STATE_TRICKLE", "a00250.html#gga784c8453c304308211f862af878e4e38a96362be8a332d5456608206082fa3489", null ],
      [ "BAT_STATE_ERROR", "a00250.html#gga784c8453c304308211f862af878e4e38a39b4be76eb384e488849af0f8601623b", null ]
    ] ],
    [ "eBatChargeGet", "a00250.html#ga992784d62051cb12980cd6ae244d3f9b", null ],
    [ "eBatProcess", "a00250.html#ga72c55f6d59a520de2c8f308f50393450", null ],
    [ "usBatVoltage", "a00250.html#ga33341d90c7a9ba66fc611a856f209623", null ],
    [ "usBatVoltageAverage", "a00250.html#ga0c289f3093f375f39b7750d22cebd6d6", null ],
    [ "usBatVoltageMax", "a00250.html#gaad7820daf52b9f84a37fdbfb9ca9a0c1", null ],
    [ "vBatChargeInit", "a00250.html#ga1006048cca04004dfce83c116f156df6", null ],
    [ "vBatChargeSet", "a00250.html#ga38529b9bcc24c0cca22dae72faae6ad6", null ],
    [ "vBatInit", "a00250.html#gae7f682bb597b1f94c4fef7f892cab5d8", null ]
];