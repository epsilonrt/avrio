var a00291 =
[
    [ "xMenu", "a00075.html", [
      [ "eFlag", "a00075.html#a6da08d23a5eb1144550e231047a75d62", null ],
      [ "iSize", "a00075.html#a012a0739c22fc369a0a1991a8b9ccee2", null ],
      [ "pcName", "a00075.html#ae6683628a012cc3583084fe9469a5e81", null ],
      [ "pxItem", "a00075.html#a7a82b0bc64d759edb5b63803036b7006", null ],
      [ "pxUp", "a00075.html#ac5a81aa28f2996db7a5d72ba84b0e409", null ]
    ] ],
    [ "xMenuItem", "a00076.html", [
      [ "eFlag", "a00076.html#a6d982b4b21ccd7755d59db3d071eafa5", null ],
      [ "pcName", "a00076.html#ae3e8aab75f5bffe168c570d0e3e87e57", null ],
      [ "pvFunc", "a00076.html#ad7c5eb492cd66f9948299346fec0135b", null ],
      [ "pvItem", "a00076.html#a72a9cc285cb8adce23cea15bd2d858f8", null ],
      [ "pxMenu", "a00076.html#a0b5bc724edf97f2902ff0e4c2619333e", null ],
      [ "xAction", "a00076.html#a0d10a7659a40700fa13d9c99248ad662", null ],
      [ "xRaw", "a00076.html#aee996f576e999dbe54c449d616001a28", null ],
      [ "xSubMenu", "a00076.html#a6505b40bcf6baace6daa041a80d8e1a0", null ]
    ] ],
    [ "MENU_SIZEOF", "a00291.html#gaf95a88607a33dbe1aa36f974aaf56b7f", null ],
    [ "pvMenuFunction", "a00291.html#ga0a8c4d0bcf3f3218150c32e914149882", null ],
    [ "eMenuFlag", "a00291.html#ga7ce81cf97e2b3a4376137d6eb075f269", [
      [ "MENU_FLAG_MENU", "a00291.html#gga7ce81cf97e2b3a4376137d6eb075f269aacfdf385cd884511fd0e4d5aa9d1a277", null ],
      [ "MENU_FLAG_ACTION", "a00291.html#gga7ce81cf97e2b3a4376137d6eb075f269a3ac01885d7ee7cb9dc685e13ce645ae8", null ],
      [ "MENU_FLAG_PGM_ITEM", "a00291.html#gga7ce81cf97e2b3a4376137d6eb075f269a6d964b700dadd4f39c9001c9880d7010", null ],
      [ "MENU_FLAG_PGM_NAME", "a00291.html#gga7ce81cf97e2b3a4376137d6eb075f269a93bdd8bd9fba7c3402d7da4787ca0540", null ],
      [ "MENU_FLAG_PGM_ALL", "a00291.html#gga7ce81cf97e2b3a4376137d6eb075f269abbf2f5d96da7c38293be4f5e877a2ede", null ]
    ] ],
    [ "eMenuPoll", "a00291.html#gad4795a134d21a0c30ba0c1c039a797ea", null ]
];