var a00313 =
[
    [ "xTwiId", "a00313.html#ga490e1ec37209a43b90c1abc2983b700e", null ],
    [ "eTwiGetRxFrame", "a00313.html#ga32c90025cf70378c010c1100daf654e3", null ],
    [ "eTwiGetStatus", "a00313.html#ga31ce2a2237282c76fa6ad0eec2f6f361", null ],
    [ "eTwiMem16Read", "a00313.html#ga71805d1ed5b4679a7d2a435d0738ec60", null ],
    [ "eTwiMem16Write", "a00313.html#gab650ed1050ca9108ab894858a2829f32", null ],
    [ "eTwiMem8Read", "a00313.html#gaabc086d13429f59eda08ed84ecf37c0a", null ],
    [ "eTwiMem8Write", "a00313.html#ga1179074d1e009acc4fe6088f474d5388", null ],
    [ "eTwiRead", "a00313.html#gaf5dbf1dc9b824b44af8d311c196bedae", null ],
    [ "eTwiReceive", "a00313.html#gab1d770c5cd701f40fe4707de6186e835", null ],
    [ "eTwiSend", "a00313.html#ga4212c3b9a786b12c3b43adf236e3e93f", null ],
    [ "eTwiSetSpeed", "a00313.html#ga86f7cd4ab874233506ccd94073b83194", null ],
    [ "eTwiWrite", "a00313.html#ga4769477300ed47d3cd70af8907f7d11d", null ],
    [ "xTwiTryReceive", "a00313.html#gade70bcb25a94618dba188c09a81215af", null ],
    [ "xTwiTrySend", "a00313.html#gaffcfd399cb6015469f9a536c897bb137", null ]
];