var a00289 =
[
    [ "iNumberOfBlocksInFreeList", "a00289.html#gae8f5589ca51a0e6788be97e5254105f4", null ],
    [ "ulFreeListSize", "a00289.html#gae91515acfbc90500c49d57d5678face4", null ],
    [ "ulFreeMemory", "a00289.html#gafe0edc149be09ff60714fe93feeae120", null ],
    [ "ulLargestAvailableMemoryBlock", "a00289.html#ga794359e0b9e8163e565418176df20dfb", null ],
    [ "ulLargestBlockInFreeList", "a00289.html#ga7b4587d74dad5c11fa8038071d94b646", null ],
    [ "ulLargestNonFreeListBlock", "a00289.html#gaa339413baf134fcb726205414a62b5b0", null ],
    [ "ulMemoryUsed", "a00289.html#gafe6ad4c267fcd7b40a314e1833868dde", null ]
];