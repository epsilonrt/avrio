var a00237 =
[
    [ "eAdcRef", "a00237.html#ga69f608d59a555a7c535d5d735934b5d4", [
      [ "eAdcExternal", "a00237.html#gga69f608d59a555a7c535d5d735934b5d4abe5f8ebd0f2cc8a83f60af824a1cba0a", null ],
      [ "eAdcVcc", "a00237.html#gga69f608d59a555a7c535d5d735934b5d4a82acc68be51661abafab1ba1472faf4b", null ],
      [ "eAdcInternal", "a00237.html#gga69f608d59a555a7c535d5d735934b5d4a53b88120e44491f2b1d3781f50fcb145", null ]
    ] ],
    [ "ucAdcGetDiv", "a00237.html#ga16091af07d4eb4861de0e407d83de93c", null ],
    [ "usAdcRead", "a00237.html#ga06c873bec019184b3ca40004145bbbca", null ],
    [ "usAdcReadAverage", "a00237.html#gaf2791a2967484c22581ae0866c4ec300", null ],
    [ "vAdcDisable", "a00237.html#gae87c136f2f7d1a1bdebc50bcb5f00724", null ],
    [ "vAdcEnable", "a00237.html#ga7b63d353cf77f8ce275b48ed133135db", null ],
    [ "vAdcInit", "a00237.html#gafd363a68cef637598cf2717923f633b8", null ],
    [ "vAdcSetChannel", "a00237.html#ga4cfaa08fb2ebfc9d8c43b51a4c179b54", null ],
    [ "vAdcSetDiv", "a00237.html#ga505b62ccbc251745829be245d95472bc", null ],
    [ "vAdcSetRef", "a00237.html#gab7efb6519841c9f14523ff0c6668f773", null ]
];