var a00248 =
[
    [ "Configuration", "a00249.html", "a00249" ],
    [ "xAx25", "a00058.html", [
      [ "buf", "a00058.html#a2f2c520ae11e59739252d7e4a7da46c2", null ],
      [ "crc_in", "a00058.html#a7bac4e9136305758487ee25192b1fac8", null ],
      [ "crc_out", "a00058.html#a08b73839f080953459f35ba9f3dc9d4c", null ],
      [ "escape", "a00058.html#a946dfcc0cbaed9431217fa2b40f6a241", null ],
      [ "fin", "a00058.html#a046639a352e390fafc2d678c70b60e81", null ],
      [ "fout", "a00058.html#a8269e309458ccb2a04f767af498aa36d", null ],
      [ "frm_len", "a00058.html#a997739c126c801f5772c1cbd4b736ecc", null ],
      [ "hook", "a00058.html#aa0f007432528897783610e8adebec4ce", null ],
      [ "sync", "a00058.html#a7b71764cc5330e3547ce43e55cf30b90", null ]
    ] ],
    [ "xAx25Frame", "a00059.html", [
      [ "ctrl", "a00059.html#ac390866554fab560783b5d5295e26814", null ],
      [ "dst", "a00059.html#aebaf71207191966428926e3499972700", null ],
      [ "info", "a00059.html#a143cdd82eb501603885837ee57ba0ed8", null ],
      [ "len", "a00059.html#ab0aebef9689ddef22008937728c28017", null ],
      [ "pid", "a00059.html#ac1eb9aa106d0bcc9d3c1fe6fde148470", null ],
      [ "src", "a00059.html#acab1b118e8dfd39c065e93d363af4f65", null ]
    ] ],
    [ "xAx25Node", "a00060.html", [
      [ "call", "a00060.html#a94ff5175029c0b2249649c4dae640717", null ],
      [ "ssid", "a00060.html#a50e0032f62051e3f3d2f649d2d81b8e6", null ]
    ] ],
    [ "AX25_CALL", "a00248.html#ga5327edd4421eb544c6ef1a6b6b57c3d5", null ],
    [ "AX25_CTRL_UI", "a00248.html#ga814fed3e2218ff674eb8866493379c66", null ],
    [ "AX25_MAX_RPT", "a00248.html#gaca2813d00ec3666b450f4de16c225d38", null ],
    [ "AX25_MIN_FRAME_LEN", "a00248.html#ga4dc6bc53a35714e315e64780885500d5", null ],
    [ "AX25_PATH", "a00248.html#ga46f680eba52bb13a331f9821bbdccf43", null ],
    [ "AX25_PID_NOLAYER3", "a00248.html#ga88892802325a651f80dcc1c7947ad2eb", null ],
    [ "vAx25Send", "a00248.html#ga7408b482639c924d691394459e859633", null ],
    [ "vAx25CallBack", "a00248.html#ga0f88f478a8c8fad978ce874e1fd5c6cf", null ],
    [ "xAx25", "a00248.html#ga9f88ee7e2f6f2eeb144e5c3121757559", null ],
    [ "xAx25Frame", "a00248.html#gaa0167828133ceb6f5bbccebc49c61a7e", null ],
    [ "xAx25Node", "a00248.html#gaec94ac26628bcfbdc7487fab187e070c", null ],
    [ "vAx25Init", "a00248.html#gaa8dd71058c583b068363bfbb2114ea05", null ],
    [ "vAx25Poll", "a00248.html#ga8907af79e5cfdc0cdd7b48def6184a82", null ],
    [ "vAx25Print", "a00248.html#gaa783fa9c528239eb7c48c5dcd8adad39", null ],
    [ "vAx25SendVia", "a00248.html#ga70a29c2f3b20f8118c40b431d1072770", null ]
];