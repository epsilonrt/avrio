var NAVTREE =
[
  [ "AvrIO", "index.html", [
    [ "Présentation", "index.html", null ],
    [ "Modules", "modules.html", "modules" ],
    [ "Structures de données", null, [
      [ "Structures de données", "annotated.html", "annotated" ],
      [ "Index des structures de données", "classes.html", null ],
      [ "Champs de donnée", "functions.html", [
        [ "Tout", "functions.html", null ],
        [ "Variables", "functions_vars.html", null ]
      ] ]
    ] ],
    [ "Exemples", "examples.html", "examples" ]
  ] ]
];

var NAVTREEINDEX =
[
"a00002.html",
"a00104.html",
"a00239.html#gadb056877043b2fcf1477cf3a69bb89a6",
"a00262.html#gga05f65aed7e1178a485de99235f8d3f8aa9c954bcf443428c80b0f107b3bc48749",
"a00283.html#ga7c034962522e1f421dd8ca3ffe0ab154",
"a00304.html#ggadae8b1d38eeb34e3cdf21f19d957f772a08f449764a2022571435668382b657e4",
"a00315.html#gaaf97061fee9e48a516e7ba311508b1d3"
];

var SYNCONMSG = 'cliquez pour désactiver la synchronisation du panel';
var SYNCOFFMSG = 'cliquez pour activer la synchronisation du panel';