var a00316 =
[
    [ "eWNetRxPktWait", "a00316.html#ga07a6e93e7820f12b23005ff1d3446ffe", null ],
    [ "pucWNetRxPktBytes", "a00316.html#ga2ff62ecd0cb2f765dfa5d769c9387ffc", null ],
    [ "pucWNetRxPktDataPayload", "a00316.html#ga29c45913276449c3f524175a4c9b0f98", null ],
    [ "pxWNetRxPacket", "a00316.html#ga942c0add6cfb0e204727a6029b99ee41", null ],
    [ "ucWNetAckTimeout", "a00316.html#gaa655d3dcb27248034ed8a5fec32e6e7f", null ],
    [ "ucWNetBindTimeout", "a00316.html#gae68239dbf2b6d37b52408017c92361bb", null ],
    [ "ucWNetPingTimeout", "a00316.html#ga7af1596125bad82cf8bbbc76e9afb2ea", null ],
    [ "ucWNetRxPktByte", "a00316.html#gaff72c55215c35fbfbce4a3c01f902dfb", null ],
    [ "ucWNetRxPktDataPayloadLength", "a00316.html#ga27770860732d89c1ef50679efdf683bc", null ],
    [ "ucWNetRxPktHeader", "a00316.html#ga7a5234cdb12cf219c272ddbd64f06838", null ],
    [ "ucWNetRxPktType", "a00316.html#ga79a6a90fb8eac70ec9a4d13e3a3570e6", null ],
    [ "ulWNetRxPktDword", "a00316.html#gaeea0e2032b038e2cc3c1c0834bbe7980", null ],
    [ "usWNetRxPktDeviceId", "a00316.html#gaa86d52da661ca5eea04091274805245a", null ],
    [ "usWNetRxPktWord", "a00316.html#ga0bf9e4dd35a86ac5f60bb1ed231b9783", null ],
    [ "xWNetRxPktFlag", "a00316.html#ga591bfa0a84c706fc100e5f83fa51347d", null ]
];