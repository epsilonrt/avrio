var a00227 =
[
    [ "Convertisseur Analogique-Numérique", "a00237.html", "a00237" ],
    [ "Capteurs analogiques", "a00238.html", "a00238" ],
    [ "Chargeur de batterie NiCd/NiMh", "a00253.html", "a00253" ],
    [ "Relais bistables", "a00255.html", "a00255" ],
    [ "Boutons poussoirs", "a00256.html", "a00256" ],
    [ "Mémoire EEPROM", "a00266.html", "a00266" ],
    [ "Capteur de pression Honeywell HSC", "a00272.html", "a00272" ],
    [ "Clavier matriciel", "a00275.html", "a00275" ],
    [ "LCD alphanumérique", "a00276.html", "a00276" ],
    [ "LED", "a00286.html", "a00286" ],
    [ "Génération de mélodies musicales", "a00287.html", "a00287" ],
    [ "Cartes mémoire MMC/SD", "a00292.html", "a00292" ],
    [ "Gestion d'une ligne téléphonique avec décodage DTMF", "a00293.html", "a00293" ],
    [ "Horloge \"Temps réel\"", "a00298.html", "a00298" ],
    [ "Liaison série asynchrone", "a00300.html", "a00300" ],
    [ "Liaison série asynchrone logicielle", "a00301.html", "a00301" ],
    [ "Micro-interrupteurs", "a00305.html", "a00305" ],
    [ "Terminal texte", "a00290.html", "a00290" ],
    [ "tiny HMI", "a00307.html", "a00307" ],
    [ "Interface mémoire externe", "a00326.html", "a00326" ]
];