var a00254 =
[
    [ "eBdcmControl", "a00254.html#ga25e9d2b9160f0c76e28edada72794383", [
      [ "BDCM_FREE", "a00254.html#gga25e9d2b9160f0c76e28edada72794383aab9ce45ad27706df36918102e4c4d7d5", null ],
      [ "BDCM_FORWARD", "a00254.html#gga25e9d2b9160f0c76e28edada72794383ae6db371afc03aeda47192daff63b2fdd", null ],
      [ "BDCM_REVERSE", "a00254.html#gga25e9d2b9160f0c76e28edada72794383a42d757b506b18a43148ecbf18ffdfecc", null ],
      [ "BDCM_STOP", "a00254.html#gga25e9d2b9160f0c76e28edada72794383a973fdb5ce27c5f15d119650fd015cb37", null ]
    ] ],
    [ "sBdcmRatio", "a00254.html#gab98f704b036f850f229547a92a101f23", null ],
    [ "usBdcmFreq", "a00254.html#ga5495d6b9d88444809bcf2db2e7c47ed1", null ],
    [ "vBdcmInit", "a00254.html#gab67166f24370c9c614ce7745b8e1866b", null ],
    [ "vBdcmSetRatio", "a00254.html#ga776592f9178cd79e7fff96a60eb0ba26", null ]
];