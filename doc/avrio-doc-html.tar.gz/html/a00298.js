var a00298 =
[
    [ "xRtcTime", "a00086.html", [
      [ "ucDate", "a00086.html#a1700ae9f719055bde630bddffa78a292", null ],
      [ "ucHour", "a00086.html#aaf97e00656b44e3cb805236b1c20100a", null ],
      [ "ucMinute", "a00086.html#a6280e079cdf092c1535639952253a791", null ],
      [ "ucMonth", "a00086.html#a7e74c14b2bb1f5f1e9c2aa199f5afc1d", null ],
      [ "ucSecond", "a00086.html#af6b4028eac425379fddfa2643e4d1e73", null ],
      [ "ucWeekDay", "a00086.html#a12b6bdfdfa4887a0319238282eb57f86", null ],
      [ "usYear", "a00086.html#a6bb6154e7c660db9c24b93eaae698812", null ]
    ] ],
    [ "iRtcPrintDate", "a00298.html#ga61553c51f8df5ab0f4466238e6fa8237", null ],
    [ "iRtcPrintTime", "a00298.html#gada513f3c3e326edb78b50019a6d39820", null ],
    [ "xRtcTime", "a00298.html#ga8b02dd7c0626cee9721ee59b6a2d59d6", null ],
    [ "eRtcWeekDay", "a00298.html#ga7ab3c735ca7f3081f1e3a4e66e4a52bc", [
      [ "MONDAY", "a00298.html#gga7ab3c735ca7f3081f1e3a4e66e4a52bcac82db3248a96794aaefb922ea5fb293c", null ],
      [ "TUESDAY", "a00298.html#gga7ab3c735ca7f3081f1e3a4e66e4a52bca347c4455723bb1bc2709647607a2b282", null ],
      [ "WEDNESDAY", "a00298.html#gga7ab3c735ca7f3081f1e3a4e66e4a52bca68288a23958cd9e1705fd81f0ee729c7", null ],
      [ "THURSDAY", "a00298.html#gga7ab3c735ca7f3081f1e3a4e66e4a52bcab4bfd6f883437c6cf31486dcf03ce0ff", null ],
      [ "FRIDAY", "a00298.html#gga7ab3c735ca7f3081f1e3a4e66e4a52bca8f589731fd90a9890c0df9a9c3f96131", null ],
      [ "SATURDAY", "a00298.html#gga7ab3c735ca7f3081f1e3a4e66e4a52bca31bbcd6fa6a28095ef8de658126aa5ec", null ],
      [ "SUNDAY", "a00298.html#gga7ab3c735ca7f3081f1e3a4e66e4a52bcad86a75e0b97510de54435996ae45b8d2", null ]
    ] ],
    [ "iRtcDateToStr", "a00298.html#ga3d0d339400e0f01177d66423cd479c9a", null ],
    [ "iRtcGetAlm", "a00298.html#gadc694fa4a6097917ba8f34967c940709", null ],
    [ "iRtcGetTime", "a00298.html#ga73df93a2c1dd00ca4ea465ac22b8729b", null ],
    [ "iRtcInit", "a00298.html#gae2c1071b788a1ca6b25109d4c70c6b2d", null ],
    [ "iRtcPrintDateToStream", "a00298.html#gafd12715be42d8b433aef13ae2191ac6e", null ],
    [ "iRtcPrintTimeToStream", "a00298.html#gaef77af21c7bdfdbd330db035d7d95076", null ],
    [ "iRtcSetAlm", "a00298.html#ga47ee98f3d05e987225f5423a25e01f37", null ],
    [ "iRtcSetTime", "a00298.html#gaadbe85d0ffc85dd909c814e45cda5368", null ],
    [ "iRtcTimeToStr", "a00298.html#ga3946fc091f35bff483146e40e439d895", null ],
    [ "pcRtcWeekdayToStr", "a00298.html#ga5ff048dd511a6febffe9c903cd017a3c", null ],
    [ "pxRtcAlmMutex", "a00298.html#ga3ef8912a2714fa4db479b8b6882db724", null ],
    [ "pxRtcHeartBeatsMutex", "a00298.html#gae35c5da4d65f2f0bef26342975cd4696", null ],
    [ "xRtcYearIsLeap", "a00298.html#gaa4f29d73e7f387209ee2e136fb7f88e8", null ]
];