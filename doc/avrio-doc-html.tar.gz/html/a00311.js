var a00311 =
[
    [ "xWSensorDataBase", "a00101.html", [
      [ "usNextFreeDeviceId", "a00310.html#gacecc52ba3937a0cef0fe6e5e7b202c56", null ],
      [ "usSize", "a00310.html#gaf8cf9ba8e1dcc70801a6399e13450895", null ]
    ] ],
    [ "xWSensorRecord", "a00102.html", [
      [ "pucBackData", "a00310.html#ga03117ab349aad42286598a88e33aa4cf", null ],
      [ "ucBackDataLength", "a00310.html#gaf0574e568a43013297a246f6f5e59cdb", null ],
      [ "ucFlag", "a00310.html#ga822b1a20c6356f88dae412b0a3cf59bd", null ],
      [ "ulMid", "a00310.html#ga8352fd35c25e5a810e7c52252ff5fd41", null ]
    ] ],
    [ "WSDBASE_SENSOR_DBASE_SIZE", "a00311.html#ga4b4754c58a9816c013d16dc4444a1b28", null ],
    [ "WSDBASE_SENSOR_FILE_SIZE", "a00311.html#ga97816e24c56e52b9364e1f6cc8cb28fa", null ],
    [ "WSDBASE_SENSOR_INIT_FLAGS", "a00311.html#gac55226ce4c831fb1a15371ab079c9b49", null ],
    [ "xWSensorDataBase", "a00311.html#gab0797708da0a75bfe3ecc26ef12effc3", null ],
    [ "xWSensorRecord", "a00311.html#gaed40ac5c8a00396f3f66078cdf307c36", null ],
    [ "eWSensorRecordFlags", "a00311.html#ga24e056fa6367a2174825c20af2f53da0", [
      [ "WSDBASE_VALID_DID", "a00311.html#gga24e056fa6367a2174825c20af2f53da0a133977457680fc67d4adf80d40a75c60", null ],
      [ "WSDBASE_TX_SEQN", "a00311.html#gga24e056fa6367a2174825c20af2f53da0a512eaf8d690dc4a6c789cfd96177fb8d", null ],
      [ "WSDBASE_RX_SEQN", "a00311.html#gga24e056fa6367a2174825c20af2f53da0ad91f0ae65ee4bfccbf67d1dbd8bacafb", null ],
      [ "WSDBASE_BACKDATA", "a00311.html#gga24e056fa6367a2174825c20af2f53da0a94f30b358118c7264a964dd34d41fe1b", null ],
      [ "WSDBASE_NOTIFY", "a00311.html#gga24e056fa6367a2174825c20af2f53da0adf198fdbcb2881386a572054fd515d86", null ]
    ] ],
    [ "iWSdBaseInit", "a00311.html#ga9c5ec4e4128cbfb90531bfad3b709890", null ],
    [ "iWSdBaseOpen", "a00311.html#ga6b66c0c1d3149551964c511ea6ce4cbd", null ],
    [ "iWSdBaseRead", "a00311.html#gac2919fc890204ba61f61fbd8d82becc7", null ],
    [ "iWSdBaseWrite", "a00311.html#ga4ab54b879c1eb9050408a47b7959287a", null ],
    [ "ucWSdBaseSensorBackData", "a00311.html#ga70ed91cfe11e1c05c78ed7b2d37bcd9c", null ],
    [ "ucWSdBaseSensorBackDataLength", "a00311.html#gac366dcc940ba62a666444413d5b0cc01", null ],
    [ "ucWSdBaseSensorFlag", "a00311.html#ga7bd8a6fa7af9e43df438d77fca61fa0e", null ],
    [ "ulWSdBaseSensorMid", "a00311.html#ga2d8b0079a2d899e939bac4c79097a40d", null ],
    [ "usWSdBaseAddSensor", "a00311.html#ga912ba249e720cc6f66c65f6d6eb0ed39", null ],
    [ "usWSdBaseLength", "a00311.html#gaa5dd9b461b825c9a464595aecf17ce8c", null ],
    [ "usWSdBaseNextFreeDeviceId", "a00311.html#gab7ac18f93fb8d8a0d1dc5a9539fc3393", null ],
    [ "usWSdBaseSize", "a00311.html#ga7d25867f0bc261cd789eb701fb110d11", null ],
    [ "vWSdBaseClear", "a00311.html#ga76d0627db82e668faf09c37bd4463529", null ],
    [ "vWSdBaseFindNextFreeDeviceId", "a00311.html#gabebf9c5cebecd3a35d584b4f257070d7", null ],
    [ "vWSdBaseSensorSetBackData", "a00311.html#gae7e53c6547eb07e8519386ee167fd04d", null ],
    [ "vWSdBaseSensorSetBackDataLength", "a00311.html#gaa9bd7770934e2b6304c5ba29c34914f0", null ],
    [ "vWSdBaseSensorSetFlag", "a00311.html#ga3f7022235c06a8b9a1ad882fac9c4947", null ],
    [ "vWSdBaseSensorSetMid", "a00311.html#ga6dfc66d0db645f50273b7770c009e5f4", null ],
    [ "vWSdBaseSetLength", "a00311.html#ga4a90d2e7c0d426da2b6587c387a4ef41", null ],
    [ "xWSdBaseDeleteSensor", "a00311.html#ga1baac379d6fb8939df87b61299159279", null ]
];