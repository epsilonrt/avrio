var a00242 =
[
    [ "CONFIG_AFSK_PREAMBLE_LEN", "a00242.html#ga7e4779383e6235749b7a72fffc601fa2", null ],
    [ "CONFIG_AFSK_RX_BUFLEN", "a00242.html#gadb056877043b2fcf1477cf3a69bb89a6", null ],
    [ "CONFIG_AFSK_TRAILER_LEN", "a00242.html#ga438c5dd5041a940e200ab24f209e323e", null ],
    [ "CONFIG_AFSK_TX_BUFLEN", "a00242.html#gadc5f6ad59595e8b2c14827f5012c6f4f", null ]
];