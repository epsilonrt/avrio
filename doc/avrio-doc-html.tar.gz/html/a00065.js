var a00065 =
[
    [ "iMax", "a00065.html#ad4cc00b17ed82c67ac9a176fe813d359", null ],
    [ "iMin", "a00065.html#a12fd269cd657ee1b5bca340eb394e747", null ]
];