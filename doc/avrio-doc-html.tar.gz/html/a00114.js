var a00114 =
[
    [ "ch_mask", "a00114.html#a23d778c561a4d3dc81cdf3b35509d239", null ],
    [ "data", "a00114.html#aa4b14741e0dfa33ebec2d0543e980fc6", null ],
    [ "hdr", "a00114.html#a0064302e5c61c6a2c5b70243be0972b8", null ],
    [ "num_samples", "a00114.html#a424873efecddc9b100debacad8a82f62", null ],
    [ "opt", "a00114.html#a5cf472cb3d751c2f397f2cba8a913da6", null ],
    [ "rssi", "a00114.html#a73ae1a5032be9b6d5df619690f0323ad", null ],
    [ "src", "a00114.html#a26115745a4fe2cddfc52bd7618b57dcb", null ],
    [ "type", "a00114.html#aa79fbb71259eeec8944346fc74a6c1c4", null ]
];