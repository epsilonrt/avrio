var a00318 =
[
    [ "eWSensorError", "a00318.html#ga1c0575fd4c13dd87ff2d604b0ff6bd8b", [
      [ "WSENSOR_SUCCESS", "a00318.html#gga1c0575fd4c13dd87ff2d604b0ff6bd8ba109ca99a0def2a61c9de7287b74d8f78", null ],
      [ "WSENSOR_NACK_TIMEOUT", "a00318.html#gga1c0575fd4c13dd87ff2d604b0ff6bd8bae62880ccdc18b1a6ea98d8ef02047028", null ],
      [ "WSENSOR_PACKET_ERROR", "a00318.html#gga1c0575fd4c13dd87ff2d604b0ff6bd8ba3952b746d5a802e6b9275b50d41f3188", null ],
      [ "WSENSOR_NODE_UNBOUND", "a00318.html#gga1c0575fd4c13dd87ff2d604b0ff6bd8baebab01c41fc10cfea3572cd722eb13e6", null ],
      [ "WSENSOR_NODE_REBOUND", "a00318.html#gga1c0575fd4c13dd87ff2d604b0ff6bd8ba85ec6b1f0262700ac9d4433d716b884b", null ],
      [ "WSENSOR_SEARCH_TIMEOUT", "a00318.html#gga1c0575fd4c13dd87ff2d604b0ff6bd8bae5d227db6ac435707e2d203a88fb52d3", null ],
      [ "WSENSOR_BIND_TIMEOUT", "a00318.html#gga1c0575fd4c13dd87ff2d604b0ff6bd8bac834482ed4646917658fc824123c858d", null ]
    ] ],
    [ "eWSensorFlags", "a00318.html#ga9c1246145a0b264c8853d7ffc822196d", [
      [ "WSENSOR_EEPROMBLANK", "a00318.html#gga9c1246145a0b264c8853d7ffc822196da97bd752efc960cc2fe797880fedb407e", null ],
      [ "WSENSOR_AUTOSEEDEDBIND", "a00318.html#gga9c1246145a0b264c8853d7ffc822196daf05f06daf5b490a1239b5631ffa76298", null ],
      [ "WSENSOR_NACK", "a00318.html#gga9c1246145a0b264c8853d7ffc822196da652424c8481f814cb30be86084b35a90", null ],
      [ "WSENSOR_CHANSEARCH", "a00318.html#gga9c1246145a0b264c8853d7ffc822196dafd11eab46036295d57171e4c253098be", null ],
      [ "WSENSOR_BACKDATA", "a00318.html#gga9c1246145a0b264c8853d7ffc822196dae91a02641dff4b32fff10685f5242d60", null ],
      [ "WSENSOR_BINDING", "a00318.html#gga9c1246145a0b264c8853d7ffc822196daa361fb8f0cde67c31d8c3c394658894d", null ],
      [ "WSENSOR_BOUND", "a00318.html#gga9c1246145a0b264c8853d7ffc822196dafd45a598e355c6432879ee95e6b9ac22", null ]
    ] ],
    [ "iWSensorDataSend", "a00318.html#ga2444e7866d3ca71a63e7a5f427b929d4", null ],
    [ "pucWSensorBackDataPayload", "a00318.html#gaf837eebf4720e15591d6a90dadb3f8ce", null ],
    [ "ucWSensorBackDataPayloadLength", "a00318.html#ga69b13d382b5d121cc939a226413cca6f", null ],
    [ "usWSensorDeviceId", "a00318.html#gac96551a85298778c3fc1a1c49fff8089", null ],
    [ "vWSensorBind", "a00318.html#ga4a7c89b18c252e794eeff2bba40aab91", null ],
    [ "vWSensorDataAddByte", "a00318.html#ga760010168d7be57686284aec69700bac", null ],
    [ "vWSensorDataAddBytes", "a00318.html#ga1fe089eee7a278525a65ccd069792f02", null ],
    [ "vWSensorDataAddBytes_P", "a00318.html#ga0ea418dd829a23604d8fef0b3590a9c8", null ],
    [ "vWSensorDataAddStr", "a00318.html#ga595022ccff61e6593f029547f672b9d1", null ],
    [ "vWSensorDataAddStr_P", "a00318.html#gade3fbccb17270d8c99be05e7cbb8c742", null ],
    [ "vWSensorDataAddWord", "a00318.html#ga7778e91760ddcb8ce5902c8528257852", null ],
    [ "vWSensorDataClear", "a00318.html#gafe6dd1ec321fb6e3d870b3ff44aa594a", null ],
    [ "vWSensorInit", "a00318.html#gacef5ace191214c2f430eb8f22b3ae5cb", null ],
    [ "vWSensorSetAutoSeededBind", "a00318.html#gae88c2ce8891b1679104e5471746e1c28", null ],
    [ "vWSensorSleep", "a00318.html#gafdd29e16d6e84400c7c8341a0c9133ba", null ],
    [ "vWSensorSleepCB", "a00318.html#ga8384ba051862e56342a449ca142b668a", null ],
    [ "xWSensorAutoSeededBind", "a00318.html#ga478b2ee8bbc25ecdc8442ba5afb32fdd", null ],
    [ "xWSensorBound", "a00318.html#ga4d228f9052ed43060a5d99215725ac11", null ],
    [ "xWSensorFlag", "a00318.html#gacfed589f841cad2a5f4503c1393908ae", null ]
];