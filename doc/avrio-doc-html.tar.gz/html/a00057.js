var a00057 =
[
    [ "xLin", "a00057.html#add4c077435d6c270f2a69e1864aea689", null ],
    [ "xNlin", "a00057.html#af0ab8dde341ab73ee206bbba9a0b8c0a", null ]
];