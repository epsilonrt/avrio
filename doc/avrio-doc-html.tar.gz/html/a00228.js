var a00228 =
[
    [ "Réseau WirelessUSB", "a00232.html", "a00232" ],
    [ "Bus I2C", "a00233.html", "a00233" ],
    [ "Liaisons radio", "a00235.html", "a00235" ],
    [ "Bus CAN", "a00257.html", "a00257" ],
    [ "Liaison HDLC", "a00269.html", "a00269" ],
    [ "Bus SPI", "a00302.html", "a00302" ],
    [ "XBee", "a00324.html", "a00324" ]
];