var a00058 =
[
    [ "buf", "a00058.html#a2f2c520ae11e59739252d7e4a7da46c2", null ],
    [ "crc_in", "a00058.html#a7bac4e9136305758487ee25192b1fac8", null ],
    [ "crc_out", "a00058.html#a08b73839f080953459f35ba9f3dc9d4c", null ],
    [ "escape", "a00058.html#a946dfcc0cbaed9431217fa2b40f6a241", null ],
    [ "fin", "a00058.html#a046639a352e390fafc2d678c70b60e81", null ],
    [ "fout", "a00058.html#a8269e309458ccb2a04f767af498aa36d", null ],
    [ "frm_len", "a00058.html#a997739c126c801f5772c1cbd4b736ecc", null ],
    [ "hook", "a00058.html#aa0f007432528897783610e8adebec4ce", null ],
    [ "sync", "a00058.html#a7b71764cc5330e3547ce43e55cf30b90", null ]
];