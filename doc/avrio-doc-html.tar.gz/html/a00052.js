var a00052 =
[
    [ "CDC_CCI_Interface", "a00052.html#a060d2ef462bcf50647a4b7e5b479d072", null ],
    [ "CDC_DataInEndpoint", "a00052.html#ab1d92b7547a106f85d8be7b0c769d8ad", null ],
    [ "CDC_DataOutEndpoint", "a00052.html#abb55a2cd238494dc44983cc46b60ad83", null ],
    [ "CDC_DCI_Interface", "a00052.html#a704e4e9c8364cb32d76e838d0fdb87d7", null ],
    [ "CDC_Functional_ACM", "a00052.html#ab53e1f03d2b647b9eec595f0db11bf8f", null ],
    [ "CDC_Functional_Header", "a00052.html#ab3b2eec35122297791bf829121405565", null ],
    [ "CDC_Functional_Union", "a00052.html#ad2404c2d0e6cdde487cf83518313432f", null ],
    [ "CDC_NotificationEndpoint", "a00052.html#a03349495c341cf7ba303b4ae12941075", null ],
    [ "Config", "a00052.html#a19776357dd07e9e13999216afe193191", null ]
];