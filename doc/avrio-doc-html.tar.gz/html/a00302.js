var a00302 =
[
    [ "Configuration du module SPI", "a00303.html", null ],
    [ "eSpiFclkDiv", "a00302.html#ga3d0a09a8df2943a25055337d5a19f0b5", [
      [ "SPI_DIV2", "a00302.html#gga3d0a09a8df2943a25055337d5a19f0b5a58901a50b61337fc44706131010ddbc8", null ],
      [ "SPI_DIV4", "a00302.html#gga3d0a09a8df2943a25055337d5a19f0b5ac5d04ac3e7680c2fb7c2b7ff250348a2", null ],
      [ "SPI_DIV8", "a00302.html#gga3d0a09a8df2943a25055337d5a19f0b5afc8af6a80403c47e2f9a93d262abd37b", null ],
      [ "SPI_DIV16", "a00302.html#gga3d0a09a8df2943a25055337d5a19f0b5a198cabaef0dfcb769c03cbe2675fcbb6", null ],
      [ "SPI_DIV32", "a00302.html#gga3d0a09a8df2943a25055337d5a19f0b5a672f1f5a6d6eeb1f8ab00543237f13b8", null ],
      [ "SPI_DIV64", "a00302.html#gga3d0a09a8df2943a25055337d5a19f0b5a249a6cc01aae03d1356d46d4b02e007e", null ],
      [ "SPI_DIV128", "a00302.html#gga3d0a09a8df2943a25055337d5a19f0b5aae9c0b289663b3c6ec3bba712025317c", null ]
    ] ],
    [ "ucSpiMasterRead", "a00302.html#ga56ac1f336436b1f6eb1c2b9be7b3185e", null ],
    [ "ucSpiMasterWriteRead", "a00302.html#ga712223f60b437e298b365dbddec45173", null ],
    [ "vSpiClearIF", "a00302.html#ga34c0ca5a7b1aeccb773b6c515acd048d", null ],
    [ "vSpiDisable", "a00302.html#ga79f2f9d32fbbff73b69a938879347fc7", null ],
    [ "vSpiEnable", "a00302.html#gab334d67f075e3fd29d42931b6d005172", null ],
    [ "vSpiMasterInit", "a00302.html#gae124445b958dcc30a79481eb6828a343", null ],
    [ "vSpiMasterWrite", "a00302.html#gae77f0f6a57327f8c7fe7da9b4f2048ce", null ],
    [ "vSpiSetSsAsInput", "a00302.html#gae761953a6c6f946b52bf6e42e3843ef0", null ],
    [ "vSpiSetSsAsOutput", "a00302.html#ga7283014adab428e01f085c5dfc83a3db", null ]
];