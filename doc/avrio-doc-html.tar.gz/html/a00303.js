var a00303 =
[
    [ "vTwiUsiSlaveHandler", "a00303.html#ga5e2da218aa0273ee63afe52692cfa17f", null ],
    [ "ucTwiUsiSlaveRead", "a00303.html#gad30efa65631f2b8506977995ca3b2f88", null ],
    [ "vTwiUsiSlaveInit", "a00303.html#ga8632b3b0f277e8a494b03e57ebe2f8e8", null ],
    [ "vTwiUsiSlaveRegisterTxHandler", "a00303.html#ga525f81b634e67b0f2b0b8195d7c1064b", null ],
    [ "vTwiUsiSlaveWrite", "a00303.html#gaa1373b7b87e736e5bea658292695d6fd", null ],
    [ "xTwiUsiSlaveCharIsReceived", "a00303.html#ga59f0ee96ac3d65978fa38ad972cca965", null ],
    [ "xTwiUsiSlaveTxBufferIsEmpty", "a00303.html#ga3f1853afdd29f5bbc1c915245ab07f04", null ]
];