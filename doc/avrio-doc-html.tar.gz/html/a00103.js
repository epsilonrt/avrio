var a00103 =
[
    [ "ucFlag", "a00103.html#aae046d837110de69167f1a2093546085", null ],
    [ "ucNoiseThreshold", "a00103.html#aa1f3eedab2484eb1ef25440acdb19f14", null ],
    [ "xConfig", "a00103.html#a20866512ddd6097dceb554659e81b930", null ],
    [ "xMsg", "a00103.html#ae394ba9b76061731ff411dd878689956", null ],
    [ "xService", "a00103.html#ac37c46d90b6f6e9efeee5d08c1919c06", null ]
];