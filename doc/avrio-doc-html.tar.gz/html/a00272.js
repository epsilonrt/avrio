var a00272 =
[
    [ "xHscRaw", "a00069.html", [
      [ "usPress", "a00069.html#ab2d7a85415b4ee4fd0d767df1087bc5e", null ],
      [ "usTemp", "a00069.html#a957e81b0224958140b80a346f7785a08", null ]
    ] ],
    [ "xHscSensor", "a00070.html", [
      [ "dPressMax", "a00070.html#a68507f51f0a34708c8424ddc6374c0b7", null ],
      [ "dPressMin", "a00070.html#a11257b6d93287cc2e91d741f6a6c32e9", null ],
      [ "eBus", "a00070.html#a70208029056d83203aa8d3999ca18940", null ],
      [ "ucI2cAddr", "a00070.html#abe928eb507fe3f9363777c905d2cfbc8", null ],
      [ "vInit", "a00070.html#a6dc339920af3eec31271997243d56fc8", null ],
      [ "vSelect", "a00070.html#ac2a53d33bd0ab0131e45c47fcfef92fa", null ]
    ] ],
    [ "xHscValue", "a00071.html", [
      [ "dPress", "a00071.html#a635330fbb5f50ac7f817fbd8bdf0a4c6", null ],
      [ "dTemp", "a00071.html#af3d8e80e78b332ff5fcf9592c3163215", null ]
    ] ],
    [ "HSC_DEFAULT_I2CADDR", "a00272.html#gac8fb5d2328bd27f40cdf8de9156a5576", null ],
    [ "PSI_TO_PA", "a00272.html#ga1d5ab1f8ea7d06b054fe9eff3ceb75f9", null ],
    [ "vHscSpiInit", "a00272.html#ga1c8c8475cbab940b365037e477d3c34f", null ],
    [ "vHscSpiSelect", "a00272.html#ga8e750267bb18f63886dbbf15da23f24f", null ],
    [ "xHscRaw", "a00272.html#gac4c2415b582058b4dd982d027cd7ce7a", null ],
    [ "xHscSensor", "a00272.html#gaa599e8ace7c2b4f1c5d0b26053317d60", null ],
    [ "xHscValue", "a00272.html#ga85df489a6956d51367c4cb9fd700d197", null ],
    [ "eHscBus", "a00272.html#ga9cf60dce3022aeebc0a21e9f7d4d8700", null ],
    [ "eHscStatus", "a00272.html#gac4b98717aabff9948ffeca62723c6c2a", [
      [ "HSC_SUCCESS", "a00272.html#ggac4b98717aabff9948ffeca62723c6c2aa1b9d3d3d67a04553bb2c8737a362b2b1", null ],
      [ "HSC_COMMAND_MODE", "a00272.html#ggac4b98717aabff9948ffeca62723c6c2aaf8aee33ded2071a2e202176138e4cdc9", null ],
      [ "HSC_STALE_DATA", "a00272.html#ggac4b98717aabff9948ffeca62723c6c2aa1dba4a7d858462967c89c16e5bf72188", null ]
    ] ],
    [ "iHscGetRaw", "a00272.html#ga6eb9c6fc7f8a8d1b91464a9a48f5e7f6", null ],
    [ "iHscGetValue", "a00272.html#ga7200c171eac0873115666185288736fd", null ],
    [ "iHscInitSpiSensor", "a00272.html#gaa329cb9e2de8376392291ff639fca4ca", null ],
    [ "vHscRawToValue", "a00272.html#ga376ca3c02b43f6a5434db9dfcca69467", null ]
];