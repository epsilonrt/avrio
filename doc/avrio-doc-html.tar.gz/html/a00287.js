var a00287 =
[
    [ "MMC_SECTOR_SIZE", "a00287.html#ga502a0143be4c303f3006c0888e1cec82", null ],
    [ "eMmcError", "a00287.html#gae39e01d87556148c7474683d27add72d", null ],
    [ "iMmcOpen", "a00287.html#ga52fa801c59214933e291e2a854e295f2", null ],
    [ "iMmcReadSector", "a00287.html#gae1b41cf7f57353e1d62550924e353ad2", null ],
    [ "iMmcWriteSector", "a00287.html#gababd81a5bdf85334816d9d623b5eff7e", null ]
];